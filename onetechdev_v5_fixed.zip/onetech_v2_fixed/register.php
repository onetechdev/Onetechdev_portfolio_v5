<?php
require_once 'inc/config.php';

// PHPMailer
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

require 'scr/PHPMailer.php';
require 'scr/SMTP.php';
require 'scr/Exception.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'register') {

    $username = clean($conn, $_POST['username'] ?? '');
    $email    = clean($conn, $_POST['email'] ?? '');
    $password = $_POST['password'] ?? '';
    $confirm  = $_POST['confirm_pass'] ?? '';
    $role     = clean($conn, $_POST['role'] ?? '');
    $experience = clean($conn, $_POST['experience'] ?? '');

    $errors = [];

    if (strlen($username) < 3) $errors[] = "Username ya yi ƙanƙanta (min 3 characters)";
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) $errors[] = "Email ba daidai ba ne";
    if (strlen($password) < 8) $errors[] = "Password ya yi ƙanƙanta (min 8 characters)";
    if ($password !== $confirm) $errors[] = "Passwords bai yi daidai ba";
    if (!in_array($role, ['developer','programmer','backend_dev','frontend_dev','server_security'])) $errors[] = "Zaɓi role daidai";

    // Check duplicates
    $chk = $conn->query("SELECT id FROM users WHERE email='$email' OR username='$username'");
    if ($chk->num_rows > 0) $errors[] = "Email ko username yana wanzu";

    if (empty($errors)) {
        $hashed = password_hash($password, PASSWORD_DEFAULT);
        $token  = bin2hex(random_bytes(32));

        $sql = "INSERT INTO users (username, email, password, role, experience, verify_token)
                VALUES ('$username','$email','$hashed','$role','$experience','$token')";

        if ($conn->query($sql)) {
            // Send welcome email
            $mail = new PHPMailer(true);
            try {
                $mail->isSMTP();
                $mail->Host       = MAIL_HOST;
                $mail->SMTPAuth   = true;
                $mail->Username   = MAIL_USERNAME;
                $mail->Password   = MAIL_PASSWORD;
                $mail->SMTPSecure = 'tls';
                $mail->Port       = MAIL_PORT;
                $mail->setFrom(MAIL_FROM, MAIL_NAME);
                $mail->addAddress($email, $username);
                $mail->isHTML(true);
                $mail->Subject = "Barka da zuwa Onetech Dev Community!";
                $verifyLink = SITE_URL . "/verify.php?token=$token";
                $mail->Body = "
                <div style='font-family:Poppins,sans-serif;background:#111;color:white;padding:30px;border-radius:10px;'>
                    <h2 style='color:#00d4ff;'>Barka da zuwa Onetech Dev! 🚀</h2>
                    <p>Sannu <strong>$username</strong>! An yi rajistar ka a matsayin <strong>$role</strong>.</p>
                    <p>Danna wannan button don tabbatar email dinka:</p>
                    <a href='$verifyLink' style='background:#00d4ff;color:#000;padding:12px 25px;border-radius:5px;text-decoration:none;font-weight:bold;display:inline-block;margin:15px 0;'>Tabbatar Email</a>
                    <p style='color:#aaa;font-size:0.85rem;'>Idan ba kai ba ka yi wannan, ka yi watsi da wannan email.</p>
                </div>";
                $mail->send();
            } catch (Exception $e) {
                // Email failed but registration ok
            }

            // Auto login
            $user = $conn->query("SELECT * FROM users WHERE email='$email'")->fetch_assoc();
            $_SESSION['user_id']   = $user['id'];
            $_SESSION['username']  = $user['username'];
            $_SESSION['role']      = $user['role'];

            redirect('home.php');
        } else {
            echo json_encode(['success'=>false,'msg'=>'Kuskure! Sake gwadawa.']);
        }
    } else {
        // Return errors to show in modal
        $errorMsg = implode('<br>', $errors);
        echo "<script>
            window.opener && window.opener.document.getElementById('reg-msg').innerHTML = '<span style=\"color:#f55\">".$errorMsg."</span>';
            history.back();
        </script>";
        // For direct form submit, store in session and redirect back
        $_SESSION['reg_error'] = $errorMsg;
        redirect('index.php#join');
    }
}

// If accessed directly without POST
redirect('index.php');
?>