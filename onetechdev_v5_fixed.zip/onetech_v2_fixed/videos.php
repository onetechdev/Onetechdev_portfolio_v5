<?php
require_once 'inc/config.php';
if (!isLoggedIn()) redirect('index.php');
$uid = $_SESSION['user_id'];

// AJAX like
if ($_POST['action'] ?? '' === 'like') {
    $pid = (int)($_POST['post_id'] ?? 0);
    $chk = $conn->query("SELECT id FROM post_likes WHERE post_id=$pid AND user_id=$uid");
    if ($chk->num_rows === 0) {
        $conn->query("INSERT INTO post_likes (post_id,user_id) VALUES ($pid,$uid)");
        $conn->query("UPDATE posts SET likes_count=likes_count+1 WHERE id=$pid");
        $c = $conn->query("SELECT likes_count FROM posts WHERE id=$pid")->fetch_assoc()['likes_count'];
        echo json_encode(['liked'=>true,'count'=>$c]); exit;
    } else {
        $conn->query("DELETE FROM post_likes WHERE post_id=$pid AND user_id=$uid");
        $conn->query("UPDATE posts SET likes_count=likes_count-1 WHERE id=$pid");
        $c = $conn->query("SELECT likes_count FROM posts WHERE id=$pid")->fetch_assoc()['likes_count'];
        echo json_encode(['liked'=>false,'count'=>$c]); exit;
    }
}
// AJAX follow
if ($_POST['action'] ?? '' === 'follow') {
    $fid = (int)($_POST['follow_id'] ?? 0);
    if ($fid && $fid != $uid) {
        $chk = $conn->query("SELECT id FROM follows WHERE follower_id=$uid AND following_id=$fid");
        if ($chk->num_rows === 0) {
            $conn->query("INSERT INTO follows (follower_id,following_id) VALUES ($uid,$fid)");
            $conn->query("UPDATE users SET following_count=following_count+1 WHERE id=$uid");
            $conn->query("UPDATE users SET followers_count=followers_count+1 WHERE id=$fid");
            echo json_encode(['followed'=>true]); exit;
        } else {
            $conn->query("DELETE FROM follows WHERE follower_id=$uid AND following_id=$fid");
            $conn->query("UPDATE users SET following_count=following_count-1 WHERE id=$uid");
            $conn->query("UPDATE users SET followers_count=followers_count-1 WHERE id=$fid");
            echo json_encode(['followed'=>false]); exit;
        }
    }
    exit;
}
// AJAX track view
if ($_POST['action'] ?? '' === 'track') {
    $pid = (int)($_POST['post_id'] ?? 0);
    if ($pid) {
        $conn->query("UPDATE posts SET view_count=COALESCE(view_count,0)+1 WHERE id=$pid");
        $conn->query("INSERT INTO post_interactions (user_id,post_id,post_owner_id,action)
            SELECT $uid,$pid,user_id,'view' FROM posts WHERE id=$pid
            ON DUPLICATE KEY UPDATE created_at=NOW()");
    }
    exit;
}

$me = $conn->query("SELECT * FROM users WHERE id=$uid")->fetch_assoc();
$msg_count   = $conn->query("SELECT COUNT(*) c FROM messages WHERE receiver_id=$uid AND is_read=0")->fetch_assoc()['c'];
$notif_count = $conn->query("SELECT COUNT(*) c FROM notifications WHERE user_id=$uid AND is_read=0")->fetch_assoc()['c'];

// Load videos with algorithm scoring
$_fq = $conn->query("SELECT following_id FROM follows WHERE follower_id=$uid");
$_following_ids = [];
if ($_fq) { while ($_fr = $_fq->fetch_assoc()) $_following_ids[] = $_fr['following_id']; }
$following_str = count($_following_ids) ? implode(',', $_following_ids) : '0';

$q = $conn->query("
    SELECT p.*, u.username, u.profile_pic, u.role,
        (SELECT COUNT(*) FROM post_likes WHERE post_id=p.id) AS like_count,
        (SELECT COUNT(*) FROM post_likes WHERE post_id=p.id AND user_id=$uid) AS i_liked,
        (SELECT COUNT(*) FROM comments WHERE post_id=p.id) AS comment_count,
        (SELECT id FROM follows WHERE follower_id=$uid AND following_id=p.user_id) AS i_follow
    FROM posts p JOIN users u ON p.user_id=u.id
    WHERE p.media_type='video' AND p.post_type='post' AND p.media_url!=''
    ORDER BY
        CASE WHEN p.user_id IN ($following_str) THEN 0 ELSE 1 END ASC,
        (COALESCE(p.likes_count,0)*3 + COALESCE(p.comments_count,0)*5) *
        CASE
            WHEN TIMESTAMPDIFF(HOUR, p.created_at, NOW()) <= 1  THEN 1.0
            WHEN TIMESTAMPDIFF(HOUR, p.created_at, NOW()) <= 6  THEN 0.85
            WHEN TIMESTAMPDIFF(HOUR, p.created_at, NOW()) <= 24 THEN 0.6
            WHEN TIMESTAMPDIFF(HOUR, p.created_at, NOW()) <= 48 THEN 0.3
            ELSE 0.1 END DESC
    LIMIT 50
");
?>
<!DOCTYPE html>
<html lang="ha">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Videos – Onetech Dev</title>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
<style>
:root{--accent:#00d4ff;--bg:#000;--border:#222;--sub:#888;}
*{box-sizing:border-box;margin:0;padding:0;}
body{background:var(--bg);color:#eee;font-family:'Segoe UI',sans-serif;height:100vh;overflow:hidden;}

.topbar{position:fixed;top:0;width:100%;height:52px;background:rgba(0,0,0,.6);backdrop-filter:blur(8px);
    display:flex;align-items:center;gap:12px;padding:0 14px;z-index:200;border-bottom:1px solid rgba(255,255,255,.06);}
.topbar a{color:#eee;font-size:17px;text-decoration:none;}
.topbar h2{font-size:15px;color:var(--accent);flex:1;font-weight:800;}
.topbar .tbadge{position:relative;}
.topbar .tbadge .badge{position:absolute;top:-4px;right:-6px;background:#f55;color:#fff;
    font-size:.55rem;width:14px;height:14px;border-radius:50%;display:flex;align-items:center;justify-content:center;}

/* REEL FEED */
.reel-feed{height:100vh;overflow-y:scroll;scroll-snap-type:y mandatory;-webkit-overflow-scrolling:touch;
    padding-top:52px;padding-bottom:65px;}
.reel-feed::-webkit-scrollbar{display:none;}
.reel-item{height:calc(100vh - 117px);scroll-snap-align:start;position:relative;
    display:flex;align-items:center;justify-content:center;background:#000;overflow:hidden;}
.reel-item video{width:100%;height:100%;object-fit:cover;cursor:pointer;}

/* MUTE INDICATOR */
.mute-icon{position:absolute;top:16px;right:14px;z-index:10;font-size:1.2rem;color:rgba(255,255,255,.7);
    background:rgba(0,0,0,.4);border-radius:50%;width:34px;height:34px;display:flex;align-items:center;
    justify-content:center;cursor:pointer;}

/* BOTTOM OVERLAY */
.reel-overlay{position:absolute;bottom:0;left:0;right:72px;padding:14px 14px 18px;
    background:linear-gradient(transparent,rgba(0,0,0,.75));}
.reel-user{display:flex;align-items:center;gap:8px;margin-bottom:6px;cursor:pointer;}
.reel-user img{width:36px;height:36px;border-radius:50%;border:2px solid var(--accent);object-fit:cover;}
.reel-username{font-weight:700;font-size:.88rem;}
.reel-role{font-size:.68rem;color:var(--accent);}
.follow-inline{background:rgba(0,212,255,.2);border:1px solid var(--accent);color:var(--accent);
    border-radius:20px;padding:3px 12px;font-size:.72rem;cursor:pointer;margin-left:6px;}
.follow-inline.following{background:#333;border-color:#444;color:#888;}
.reel-caption{font-size:.82rem;line-height:1.4;color:#ddd;text-shadow:0 1px 6px #000;margin-bottom:4px;
    display:-webkit-box;-webkit-line-clamp:2;-webkit-box-orient:vertical;overflow:hidden;}
.reel-caption.expanded{-webkit-line-clamp:unset;}
.reel-stats{font-size:.68rem;color:rgba(255,255,255,.7);}

/* RIGHT ACTIONS */
.reel-actions{position:absolute;right:10px;bottom:20px;display:flex;flex-direction:column;
    gap:18px;align-items:center;}
.reel-btn{display:flex;flex-direction:column;align-items:center;gap:3px;cursor:pointer;
    background:none;border:none;color:#fff;}
.reel-btn i{font-size:27px;text-shadow:0 2px 8px #000;filter:drop-shadow(0 1px 3px #000);}
.reel-btn span{font-size:.68rem;text-shadow:0 1px 4px #000;}
.reel-btn.liked i{color:#e74c3c;}

/* PLAY PAUSE INDICATOR */
.play-indicator{position:absolute;top:50%;left:50%;transform:translate(-50%,-50%);
    font-size:4rem;color:rgba(255,255,255,.7);pointer-events:none;opacity:0;transition:opacity .2s;}
.play-indicator.show{opacity:1;}

/* COMMENT SHEET */
.comment-sheet{display:none;position:fixed;bottom:65px;left:0;right:0;z-index:500;
    background:#111;border-radius:20px 20px 0 0;border-top:1px solid #222;padding:16px;
    max-height:65vh;flex-direction:column;}
.comment-sheet.open{display:flex;}
.cs-header{text-align:center;color:var(--accent);font-weight:700;margin-bottom:12px;font-size:.9rem;
    flex-shrink:0;position:relative;}
.cs-close{position:absolute;right:0;top:0;background:none;border:none;color:#888;font-size:1.1rem;cursor:pointer;}
.cs-list{flex:1;overflow-y:auto;display:flex;flex-direction:column;gap:8px;margin-bottom:10px;}
.cs-item{display:flex;gap:8px;}
.cs-item img{width:30px;height:30px;border-radius:50%;object-fit:cover;flex-shrink:0;}
.cs-bubble{background:#1a1a1a;border-radius:12px;padding:8px 12px;flex:1;}
.cs-name{font-size:.75rem;font-weight:700;color:var(--accent);}
.cs-text{font-size:.82rem;margin-top:2px;}
.cs-time{font-size:.65rem;color:#555;margin-top:3px;}
.cs-input{display:flex;gap:8px;border-top:1px solid #222;padding-top:10px;flex-shrink:0;}
.cs-input input{flex:1;background:#1a1a1a;border:1px solid var(--border);border-radius:20px;
    padding:9px 14px;color:#eee;font-size:.82rem;outline:none;}
.cs-input input:focus{border-color:var(--accent);}
.cs-input button{background:var(--accent);color:#000;border:none;border-radius:50%;width:36px;height:36px;cursor:pointer;}

/* BOTTOM NAV */
.bottom-nav{position:fixed;bottom:0;width:100%;background:#111;display:flex;
    border-top:1px solid var(--border);z-index:300;}
.bottom-nav a{flex:1;display:flex;flex-direction:column;align-items:center;padding:9px 0;
    color:var(--sub);text-decoration:none;font-size:.6rem;gap:3px;position:relative;}
.bottom-nav a.active,.bottom-nav a:hover{color:var(--accent);}
.bottom-nav a i{font-size:1.2rem;}
.bottom-nav a img{width:26px;height:26px;border-radius:50%;object-fit:cover;border:2px solid #333;}
.bottom-nav a.active img{border-color:var(--accent);}
.bottom-nav .mbadge{position:absolute;top:2px;right:14px;background:#f55;color:#fff;
    font-size:.5rem;width:13px;height:13px;border-radius:50%;display:flex;align-items:center;justify-content:center;}

/* TOAST */
.toast{position:fixed;top:62px;left:50%;transform:translateX(-50%);background:#1a1a1a;
    color:#fff;padding:9px 20px;border-radius:20px;font-size:.8rem;z-index:9999;
    border:1px solid var(--accent);opacity:0;transition:.3s;pointer-events:none;}
.toast.show{opacity:1;}

/* EMPTY */
.no-videos{text-align:center;padding:80px 20px;color:var(--sub);}
.no-videos i{font-size:3rem;display:block;margin-bottom:14px;}
</style>
</head>
<body>

<div class="topbar">
    <a href="home.php"><i class="fa fa-arrow-left"></i></a>
    <h2><i class="fa fa-play-circle"></i> Videos</h2>
    <a href="sakon.php" class="tbadge">
        <i class="fa fa-comment"></i>
        <?php if($msg_count>0):?><span class="badge"><?=$msg_count?></span><?php endif;?>
    </a>
</div>

<div class="reel-feed" id="reel-feed">
<?php if(mysqli_num_rows($q)===0): // $q from older code — fix below ?>
<div class="no-videos"><i class="fa fa-film"></i>
    Ba a sami videos ba tukuna.<br><small>Post video daga home page.</small>
</div>
<?php else:
    $vids_arr = [];
    while ($p = $q->fetch_assoc()) $vids_arr[] = $p;
    foreach ($vids_arr as $idx => $p):
    $pic     = $p['profile_pic'] ? 'uploads/'.htmlspecialchars($p['profile_pic']) : 'assets/default.png';
    $lclass  = $p['i_liked'] ? 'liked' : '';
    $fclass  = $p['i_follow'] ? 'following' : '';
    $flabel  = $p['i_follow'] ? 'Biyo' : 'Bi';
    $caption = htmlspecialchars(mb_substr($p['content']??'', 0, 120));
    $conn->query("UPDATE posts SET view_count=COALESCE(view_count,0)+1 WHERE id=".$p['id']);
?>
<div class="reel-item" id="reel-<?=$p['id']?>">
    <video preload="<?=$idx<2?'auto':'metadata'?>" loop playsinline
           src="uploads/<?=htmlspecialchars($p['media_url'])?>"
           onclick="tapVideo(this,<?=$p['id']?>)"
           data-pid="<?=$p['id']?>" data-viewed="0"></video>

    <div class="play-indicator" id="pi-<?=$p['id']?>"><i class="fa fa-pause"></i></div>

    <div class="mute-icon" id="mute-<?=$p['id']?>" onclick="toggleMute(<?=$p['id']?>)">
        <i class="fa fa-volume-mute"></i>
    </div>

    <div class="reel-overlay">
        <div class="reel-user" onclick="location.href='profile.php?id=<?=$p['user_id']?>'">
            <img src="<?=$pic?>" onerror="this.src='assets/default.png'">
            <div>
                <div class="reel-username"><?=htmlspecialchars($p['username'])?></div>
                <div class="reel-role"><?=str_replace('_',' ',ucfirst($p['role']))?></div>
            </div>
            <?php if ($p['user_id'] != $uid): ?>
            <button class="follow-inline <?=$fclass?>" id="vf-<?=$p['id']?>"
                    onclick="event.stopPropagation();vFollow(<?=$p['user_id']?>,<?=$p['id']?>)">
                <?=$flabel?></button>
            <?php endif; ?>
        </div>
        <?php if($caption): ?>
        <div class="reel-caption" id="cap-<?=$p['id']?>" onclick="expandCaption(<?=$p['id']?>)">
            <?=$caption?>
        </div>
        <?php endif; ?>
        <div class="reel-stats">
            <i class="fa fa-eye"></i> <?=number_format($p['view_count'])?> views
        </div>
    </div>

    <div class="reel-actions">
        <button class="reel-btn <?=$lclass?>" id="like-btn-<?=$p['id']?>"
                onclick="vLike(<?=$p['id']?>)">
            <i class="<?=$p['i_liked']?'fa':'far'?> fa-heart"></i>
            <span id="vlc-<?=$p['id']?>"><?=number_format($p['like_count'])?></span>
        </button>
        <button class="reel-btn" onclick="openComments(<?=$p['id']?>)">
            <i class="fa fa-comment"></i>
            <span><?=number_format($p['comment_count'])?></span>
        </button>
        <button class="reel-btn" onclick="vShare(<?=$p['id']?>)">
            <i class="fa fa-share"></i>
            <span>Share</span>
        </button>
        <button class="reel-btn" onclick="location.href='profile.php?id=<?=$p['user_id']?>'">
            <img src="<?=$pic?>" onerror="this.src='assets/default.png'"
                 style="width:40px;height:40px;border-radius:50%;border:3px solid #fff;object-fit:cover;">
        </button>
    </div>
</div>
<?php endforeach; endif; ?>
</div>

<!-- COMMENT SHEET -->
<div class="comment-sheet" id="comment-sheet">
    <div class="cs-header">
        Comments
        <button class="cs-close" onclick="closeComments()"><i class="fa fa-times"></i></button>
    </div>
    <div class="cs-list" id="cs-list"></div>
    <div class="cs-input">
        <input type="text" id="cs-input" placeholder="Rubuta comment...">
        <button onclick="sendComment()"><i class="fa fa-paper-plane"></i></button>
    </div>
</div>

<!-- BOTTOM NAV -->
<nav class="bottom-nav">
    <a href="home.php"><i class="fa fa-home"></i><span>Gida</span></a>
    <a href="videos.php" class="active"><i class="fa fa-play-circle"></i><span>Videos</span></a>
    <a href="sakon.php" style="position:relative;">
        <i class="fa fa-comment"></i>
        <?php if($msg_count>0):?><span class="mbadge"><?=$msg_count?></span><?php endif;?>
        <span>Sako</span>
    </a>
    <a href="home.php#notif"><i class="fa fa-bell"></i>
        <?php if($notif_count>0):?><span class="mbadge"><?=$notif_count?></span><?php endif;?>
        <span>Sanarwa</span></a>
    <a href="profile.php?id=<?=$uid?>">
        <img src="<?=$me['profile_pic']?:''?>" onerror="this.src='assets/default.png'">
        <span>Ni</span>
    </a>
</nav>

<div class="toast" id="toast"></div>

<script>
const MY_ID = <?=$uid?>;
let currentCommentPid = 0;
let globalMuted = true; // start muted (autoplay requirement)

// ─────────────────────────────────────────
// AUTOPLAY via IntersectionObserver
// ─────────────────────────────────────────
const obs = new IntersectionObserver((entries) => {
    entries.forEach(en => {
        const vid = en.target;
        if (en.isIntersecting && en.intersectionRatio > 0.7) {
            vid.muted = globalMuted;
            vid.play().catch(()=>{});
            // Track view once per reel-item
            const pid = vid.dataset.pid;
            if (pid && vid.dataset.viewed === '0') {
                vid.dataset.viewed = '1';
                fetch('videos.php', {method:'POST',
                    headers:{'Content-Type':'application/x-www-form-urlencoded'},
                    body:`action=track&post_id=${pid}`});
                // Update view counter in DOM
                const vc = document.querySelector(`#reel-${pid} .reel-stats`);
                if (vc) {
                    const cur = parseInt(vc.textContent.replace(/\D/g,'')) || 0;
                    vc.innerHTML = `<i class="fa fa-eye"></i> ${(cur+1).toLocaleString()} views`;
                }
            }
            updateMuteIcon(pid, globalMuted);
        } else {
            vid.pause();
        }
    });
}, {threshold: 0.7});

document.querySelectorAll('.reel-item video').forEach(v => obs.observe(v));

// ─────────────────────────────────────────
// TAP TO PAUSE/PLAY
// ─────────────────────────────────────────
function tapVideo(vid, pid) {
    const ind = document.getElementById('pi-' + pid);
    if (vid.paused) {
        vid.play();
        if (ind) { ind.querySelector('i').className='fa fa-pause'; ind.classList.add('show'); setTimeout(()=>ind.classList.remove('show'),600); }
    } else {
        vid.pause();
        if (ind) { ind.querySelector('i').className='fa fa-play'; ind.classList.add('show'); setTimeout(()=>ind.classList.remove('show'),600); }
    }
}

// ─────────────────────────────────────────
// MUTE TOGGLE (tap speaker icon)
// ─────────────────────────────────────────
function toggleMute(pid) {
    globalMuted = !globalMuted;
    document.querySelectorAll('.reel-item video').forEach(v => { v.muted = globalMuted; });
    document.querySelectorAll('.mute-icon').forEach(ic => {
        ic.innerHTML = globalMuted ? '<i class="fa fa-volume-mute"></i>' : '<i class="fa fa-volume-up"></i>';
    });
}
function updateMuteIcon(pid, muted) {
    const ic = document.getElementById('mute-' + pid);
    if (ic) ic.innerHTML = muted ? '<i class="fa fa-volume-mute"></i>' : '<i class="fa fa-volume-up"></i>';
}

// ─────────────────────────────────────────
// LIKE
// ─────────────────────────────────────────
async function vLike(pid) {
    const btn = document.getElementById('like-btn-' + pid);
    const r   = await fetch('videos.php', {method:'POST',
        headers:{'Content-Type':'application/x-www-form-urlencoded'},
        body:`action=like&post_id=${pid}`});
    const d = await r.json();
    const ic = btn.querySelector('i');
    if (d.liked) { btn.classList.add('liked'); ic.className='fa fa-heart'; }
    else         { btn.classList.remove('liked'); ic.className='far fa-heart'; }
    const cnt = document.getElementById('vlc-' + pid);
    if (cnt) cnt.textContent = d.count;
}

// ─────────────────────────────────────────
// FOLLOW
// ─────────────────────────────────────────
async function vFollow(fid, pid) {
    const btn = document.getElementById('vf-' + pid);
    const r   = await fetch('videos.php', {method:'POST',
        headers:{'Content-Type':'application/x-www-form-urlencoded'},
        body:`action=follow&follow_id=${fid}`});
    const d = await r.json();
    if (btn) {
        if (d.followed) { btn.textContent='Biyo'; btn.classList.add('following'); }
        else            { btn.textContent='Bi';   btn.classList.remove('following'); }
    }
    showToast(d.followed ? 'Ka biyo!' : 'An cire biyo');
}

// ─────────────────────────────────────────
// SHARE
// ─────────────────────────────────────────
function vShare(pid) {
    const url = window.location.origin + '/videos.php?v=' + pid;
    if (navigator.share) { navigator.share({title:'Onetech Dev Video', url}); }
    else { navigator.clipboard.writeText(url).then(()=>showToast('Link an kwafa!')); }
}

// ─────────────────────────────────────────
// COMMENTS
// ─────────────────────────────────────────
async function openComments(pid) {
    currentCommentPid = pid;
    document.getElementById('comment-sheet').classList.add('open');
    const list = document.getElementById('cs-list');
    list.innerHTML = '<div style="text-align:center;padding:20px;color:#555;"><i class="fa fa-circle-notch fa-spin"></i></div>';
    const r = await fetch(`comment.php?load=1&post_id=${pid}`);
    list.innerHTML = await r.text() || '<div style="text-align:center;padding:20px;color:#555;">Babu comments tukuna.</div>';
}
function closeComments() {
    document.getElementById('comment-sheet').classList.remove('open');
}
async function sendComment() {
    const inp = document.getElementById('cs-input');
    const msg = inp.value.trim();
    if (!msg || !currentCommentPid) return;
    await fetch('comment.php', {method:'POST',
        headers:{'Content-Type':'application/x-www-form-urlencoded'},
        body:`post_id=${currentCommentPid}&content=${encodeURIComponent(msg)}`});
    inp.value = '';
    openComments(currentCommentPid);
}
document.getElementById('cs-input').addEventListener('keydown', e => {
    if (e.key === 'Enter') sendComment();
});

// ─────────────────────────────────────────
// EXPAND CAPTION
// ─────────────────────────────────────────
function expandCaption(pid) {
    document.getElementById('cap-' + pid)?.classList.toggle('expanded');
}

// ─────────────────────────────────────────
// TOAST
// ─────────────────────────────────────────
function showToast(msg) {
    const t = document.getElementById('toast');
    t.textContent = msg; t.classList.add('show');
    setTimeout(() => t.classList.remove('show'), 2200);
}

// First click anywhere = unmute
document.addEventListener('click', () => {
    if (globalMuted) {
        globalMuted = false;
        document.querySelectorAll('.reel-item video').forEach(v => { v.muted = false; });
        document.querySelectorAll('.mute-icon').forEach(ic => {
            ic.innerHTML = '<i class="fa fa-volume-up"></i>';
        });
    }
}, {once: true});
</script>
</body>
</html>
