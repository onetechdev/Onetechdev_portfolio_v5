<?php
require_once 'inc/config.php';
if (!isLoggedIn()) exit;
$viewer_id = $_SESSION['user_id'];

// Mark as seen
if (isset($_GET['seen'])) {
    $sid = (int)$_GET['seen'];
    $conn->query("INSERT IGNORE INTO story_views_v2 (story_id,viewer_id) VALUES ($sid,$viewer_id)");
    $conn->query("UPDATE stories SET view_count=view_count+1 WHERE id=$sid");
    exit;
}

// Upload story
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_FILES['story_media'])) {
    $file = $_FILES['story_media'];
    if ($file['error'] === 0) {
        $ext    = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
        $imgs   = ['jpg','jpeg','png','gif','webp'];
        $vids   = ['mp4','webm','mov'];
        $fn     = 'story_'.uniqid().'.'.$ext;
        $dst    = 'uploads/'.$fn;
        move_uploaded_file($file['tmp_name'], $dst);
        $expires = date('Y-m-d H:i:s', strtotime('+24 hours'));
        if (in_array($ext, $imgs)) {
            $conn->query("INSERT INTO stories (user_id,image,expires_at) VALUES ($viewer_id,'$fn','$expires')");
        } else {
            $conn->query("INSERT INTO stories (user_id,video,expires_at) VALUES ($viewer_id,'$fn','$expires')");
        }
    }
    echo json_encode(['ok'=>true]);
}
