<?php
require_once 'inc/config.php';
if (!isLoggedIn()) exit;

$uid      = $_SESSION['user_id'];
$username = $_SESSION['username'];

// GET: load comments for a post
if ($_SERVER['REQUEST_METHOD'] === 'GET' && isset($_GET['load'])) {
    $pid = (int)($_GET['post_id'] ?? 0);
    $q   = $conn->query("SELECT c.*,u.username,u.profile_pic FROM comments c
        JOIN users u ON c.user_id=u.id
        WHERE c.post_id=$pid ORDER BY c.created_at ASC LIMIT 50");
    if (!$q || $q->num_rows === 0) {
        echo '<div style="text-align:center;padding:16px;color:#555;font-size:.8rem;">Babu comments tukuna.</div>';
        exit;
    }
    while ($c = $q->fetch_assoc()):
        $cpic = $c['profile_pic'] ? 'uploads/'.htmlspecialchars($c['profile_pic']) : 'assets/default.png';
        $ago  = '';
        $secs = time() - strtotime($c['created_at']);
        if ($secs < 60) $ago = $secs.'s';
        elseif ($secs < 3600) $ago = floor($secs/60).'m';
        elseif ($secs < 86400) $ago = floor($secs/3600).'h';
        else $ago = date('d M', strtotime($c['created_at']));
    ?>
<div class="comment-item">
    <img src="<?=$cpic?>" onerror="this.src='assets/default.png'">
    <div class="comment-bubble">
        <strong onclick="location.href='profile.php?id=<?=$c['user_id']?>'"><?=htmlspecialchars($c['username'])?></strong>
        <p><?=nl2br(htmlspecialchars($c['content']))?></p>
        <small><?=$ago?></small>
    </div>
</div>
    <?php endwhile;
    exit;
}

// POST: send comment
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $pid     = (int)($_POST['post_id'] ?? 0);
    $content = $conn->real_escape_string(trim($_POST['content'] ?? ''));
    if ($pid && $content) {
        $conn->query("INSERT INTO comments (post_id,user_id,content) VALUES ($pid,$uid,'$content')");
        $conn->query("UPDATE posts SET comments_count=COALESCE(comments_count,0)+1 WHERE id=$pid");
        // Track interaction
        $conn->query("INSERT INTO post_interactions (user_id,post_id,post_owner_id,action)
            SELECT $uid,$pid,user_id,'comment' FROM posts WHERE id=$pid
            ON DUPLICATE KEY UPDATE created_at=NOW()");
        // Notify
        $post = $conn->query("SELECT user_id FROM posts WHERE id=$pid")->fetch_assoc();
        if ($post && $post['user_id'] != $uid) {
            $conn->query("INSERT INTO notifications (user_id,from_user_id,type,ref_id,message)
                VALUES ({$post['user_id']},$uid,'comment',$pid,'Ya yi comment a post ɗinka')");
        }
        echo json_encode(['success'=>true]);
    }
    exit;
}
