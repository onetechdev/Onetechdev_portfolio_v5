<?php
require_once 'inc/config.php';
if (!isLoggedIn()) redirect('index.php');

$my_id      = $_SESSION['user_id'];
$profile_id = isset($_GET['id']) ? (int)$_GET['id'] : $my_id;

$me   = $conn->query("SELECT * FROM users WHERE id=$my_id")->fetch_assoc();
$user = $conn->query("SELECT * FROM users WHERE id=$profile_id")->fetch_assoc();
if (!$user) redirect('home.php');

$is_me    = ($my_id === $profile_id);
$posts_c  = $conn->query("SELECT COUNT(*) c FROM posts WHERE user_id=$profile_id AND post_type='post'")->fetch_assoc()['c'];
$followers= $conn->query("SELECT COUNT(*) c FROM follows WHERE following_id=$profile_id")->fetch_assoc()['c'];
$following= $conn->query("SELECT COUNT(*) c FROM follows WHERE follower_id=$profile_id")->fetch_assoc()['c'];
$i_follow = $conn->query("SELECT id FROM follows WHERE follower_id=$my_id AND following_id=$profile_id")->fetch_assoc();
$msg_count= $conn->query("SELECT COUNT(*) c FROM messages WHERE receiver_id=$my_id AND is_read=0")->fetch_assoc()['c'];
$notif_count=$conn->query("SELECT COUNT(*) c FROM notifications WHERE user_id=$my_id AND is_read=0")->fetch_assoc()['c'];

// JSON mode (for profile popup on home.php)
if (isset($_GET['json'])) {
    header('Content-Type: application/json');
    echo json_encode([
        'id'          => $profile_id,
        'username'    => $user['username'],
        'role'        => $user['role'],
        'bio'         => $user['bio'] ?? '',
        'profile_pic' => $user['profile_pic'] ?? '',
        'cover_pic'   => $user['cover_pic'] ?? '',
        'posts'       => $posts_c,
        'followers'   => $followers,
        'following'   => $following,
        'i_follow'    => $i_follow ? true : false,
        'work'        => $user['work'] ?? '',
        'city'        => $user['city'] ?? '',
    ]);
    exit;
}

// Handle profile/cover pic upload
if ($is_me && isset($_FILES['profile_pic']['name']) && $_FILES['profile_pic']['name']) {
    $ext = strtolower(pathinfo($_FILES['profile_pic']['name'], PATHINFO_EXTENSION));
    if (in_array($ext,['jpg','jpeg','png','gif','webp'])) {
        $fn = 'profile_'.$my_id.'_'.time().'.'.$ext;
        move_uploaded_file($_FILES['profile_pic']['tmp_name'],'uploads/'.$fn);
        $conn->query("UPDATE users SET profile_pic='$fn' WHERE id=$my_id");
        $user['profile_pic'] = $fn;
    }
}
if ($is_me && isset($_FILES['cover_pic']['name']) && $_FILES['cover_pic']['name']) {
    $ext = strtolower(pathinfo($_FILES['cover_pic']['name'], PATHINFO_EXTENSION));
    if (in_array($ext,['jpg','jpeg','png','gif','webp'])) {
        $fn2 = 'cover_'.$my_id.'_'.time().'.'.$ext;
        move_uploaded_file($_FILES['cover_pic']['tmp_name'],'uploads/'.$fn2);
        $conn->query("UPDATE users SET cover_pic='$fn2' WHERE id=$my_id");
        $user['cover_pic'] = $fn2;
    }
}

// Handle profile edit
if ($is_me && $_SERVER['REQUEST_METHOD']==='POST' && isset($_POST['edit_profile'])) {
    $uname  = $conn->real_escape_string(trim($_POST['username']??''));
    $bio    = $conn->real_escape_string(trim($_POST['bio']??''));
    $work   = $conn->real_escape_string(trim($_POST['work']??''));
    $school = $conn->real_escape_string(trim($_POST['school']??''));
    $city   = $conn->real_escape_string(trim($_POST['city']??''));
    $conn->query("UPDATE users SET username='$uname',bio='$bio',work='$work',school='$school',city='$city' WHERE id=$my_id");
    redirect('profile.php?saved=1');
}

// Follow/unfollow AJAX
if ($_POST['action'] ?? '' === 'follow') {
    $fid = (int)($_POST['follow_id'] ?? 0);
    if ($fid && $fid !== $my_id) {
        $chk = $conn->query("SELECT id FROM follows WHERE follower_id=$my_id AND following_id=$fid");
        if ($chk->num_rows === 0) {
            $conn->query("INSERT INTO follows (follower_id,following_id) VALUES ($my_id,$fid)");
            $conn->query("UPDATE users SET following_count=following_count+1 WHERE id=$my_id");
            $conn->query("UPDATE users SET followers_count=followers_count+1 WHERE id=$fid");
            $conn->query("INSERT INTO notifications (user_id,from_user_id,type,message) VALUES ($fid,$my_id,'follow','Ya biyo ka')");
            echo json_encode(['followed'=>true]); exit;
        } else {
            $conn->query("DELETE FROM follows WHERE follower_id=$my_id AND following_id=$fid");
            $conn->query("UPDATE users SET following_count=following_count-1 WHERE id=$my_id");
            $conn->query("UPDATE users SET followers_count=followers_count-1 WHERE id=$fid");
            echo json_encode(['followed'=>false]); exit;
        }
    }
    exit;
}

$pic   = $user['profile_pic'] ? 'uploads/'.htmlspecialchars($user['profile_pic']) : 'assets/default.png';
$cover = $user['cover_pic']   ? 'uploads/'.htmlspecialchars($user['cover_pic'])   : '';
$posts_q = $conn->query("SELECT p.*,
    (SELECT COUNT(*) FROM post_likes WHERE post_id=p.id) AS like_count,
    (SELECT COUNT(*) FROM comments WHERE post_id=p.id) AS comment_count
    FROM posts p WHERE user_id=$profile_id AND post_type='post'
    ORDER BY created_at DESC LIMIT 30");
?>
<!DOCTYPE html>
<html lang="ha">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title><?=htmlspecialchars($user['username'])?> – Onetech Dev</title>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
<style>
:root{--accent:#00d4ff;--bg:#0a0a0a;--card:#111;--border:#1e1e1e;--sub:#888;}
*{box-sizing:border-box;margin:0;padding:0;}
body{background:var(--bg);color:#eee;font-family:'Segoe UI',sans-serif;padding-top:60px;padding-bottom:70px;}
header{position:fixed;top:0;width:100%;height:60px;background:#111;display:flex;
    align-items:center;gap:12px;padding:0 14px;z-index:1000;border-bottom:1px solid var(--border);}
header a{color:#eee;font-size:17px;text-decoration:none;}
header h2{font-size:15px;color:var(--accent);flex:1;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;}
header .hbadge{position:relative;}
header .hbadge .badge{position:absolute;top:-4px;right:-6px;background:#f55;color:#fff;
    font-size:.55rem;width:14px;height:14px;border-radius:50%;display:flex;align-items:center;justify-content:center;}

/* COVER */
.cover{height:180px;position:relative;overflow:hidden;
    background:linear-gradient(135deg,#0f0c29,#302b63,rgba(0,212,255,.25));}
.cover img{width:100%;height:100%;object-fit:cover;}
.cover-edit{position:absolute;bottom:10px;right:10px;background:rgba(0,0,0,.6);
    color:#fff;border:none;border-radius:20px;padding:6px 12px;font-size:.75rem;cursor:pointer;}
.avatar-wrap{position:absolute;bottom:-40px;left:50%;transform:translateX(-50%);}
.avatar-wrap img{width:88px;height:88px;border-radius:50%;border:4px solid var(--accent);
    object-fit:cover;display:block;}
.avatar-edit{position:absolute;bottom:0;right:0;background:var(--accent);color:#000;
    border-radius:50%;width:26px;height:26px;display:flex;align-items:center;justify-content:center;
    cursor:pointer;font-size:.75rem;border:none;}

/* INFO */
.profile-info{text-align:center;margin-top:52px;padding:0 20px 10px;}
.profile-name{font-size:1.1rem;font-weight:800;}
.profile-username{color:var(--sub);font-size:.8rem;margin-top:2px;}
.role-badge{background:var(--accent);color:#000;padding:2px 10px;border-radius:20px;
    font-size:.7rem;font-weight:700;margin-top:6px;display:inline-block;}
.profile-bio{font-size:.82rem;color:#bbb;margin-top:8px;line-height:1.5;padding:0 20px;}
.profile-details{display:flex;flex-direction:column;gap:5px;padding:10px 20px;font-size:.8rem;color:var(--sub);}
.profile-details span{display:flex;align-items:center;gap:8px;}
.profile-details i{width:16px;color:var(--accent);}

/* STATS */
.stats-row{display:flex;justify-content:center;gap:28px;padding:12px 16px;
    background:var(--card);border-radius:12px;margin:12px 16px;}
.stat-item{text-align:center;cursor:pointer;}
.stat-num{font-size:1.2rem;font-weight:800;color:var(--accent);}
.stat-lbl{font-size:.65rem;color:var(--sub);}

/* ACTION ROW */
.action-row{display:flex;gap:8px;justify-content:center;padding:0 16px 14px;flex-wrap:wrap;}
.btn{padding:9px 18px;border-radius:20px;border:none;cursor:pointer;font-weight:700;font-size:.82rem;}
.btn-primary{background:var(--accent);color:#000;}
.btn-outline{background:transparent;color:#eee;border:1px solid var(--border);}
.btn-green{background:#2ecc71;color:#000;}
.btn-danger{background:#e74c3c;color:#fff;}
.btn-call{background:#1a1a1a;border:1px solid var(--border);color:#eee;
    display:flex;align-items:center;gap:6px;}
.btn-call:hover{border-color:var(--accent);color:var(--accent);}

/* TABS */
.tabs{display:flex;border-bottom:1px solid var(--border);margin-bottom:4px;position:sticky;top:60px;background:var(--bg);z-index:10;}
.tab{flex:1;text-align:center;padding:12px;font-size:.82rem;color:var(--sub);
    cursor:pointer;border-bottom:2px solid transparent;}
.tab.active{color:var(--accent);border-bottom-color:var(--accent);}
.tab-panel{display:none;}
.tab-panel.active{display:block;}

/* GRID */
.posts-grid{display:grid;grid-template-columns:repeat(3,1fr);gap:2px;padding:0 2px;}
.grid-item{aspect-ratio:1;overflow:hidden;cursor:pointer;background:#1a1a1a;position:relative;}
.grid-item img,.grid-item video{width:100%;height:100%;object-fit:cover;}
.grid-item .vid-icon{position:absolute;top:6px;right:6px;color:#fff;font-size:.9rem;text-shadow:0 1px 4px #000;}
.grid-item .grid-stats{position:absolute;bottom:4px;left:4px;right:4px;font-size:.65rem;color:#fff;
    background:rgba(0,0,0,.5);border-radius:6px;padding:2px 6px;display:flex;gap:8px;}
.grid-empty{text-align:center;padding:40px 20px;color:var(--sub);}
.grid-empty i{font-size:2.5rem;display:block;margin-bottom:12px;}

/* EDIT MODAL */
.modal-bg{display:none;position:fixed;inset:0;background:rgba(0,0,0,.85);z-index:2000;align-items:flex-end;justify-content:center;}
.modal-bg.open{display:flex;}
.modal{background:#111;border-radius:20px 20px 0 0;padding:20px;width:100%;max-width:520px;
    margin:auto;border:1px solid var(--border);max-height:92vh;overflow-y:auto;}
.modal h3{text-align:center;margin-bottom:16px;font-size:.95rem;color:var(--accent);}
.form-group{margin-bottom:12px;}
.form-group label{font-size:.72rem;color:var(--sub);display:block;margin-bottom:5px;}
.form-group input,.form-group textarea{width:100%;background:#1a1a1a;border:1px solid var(--border);
    border-radius:10px;padding:10px 14px;color:#eee;font-size:.88rem;outline:none;font-family:inherit;}
.form-group input:focus,.form-group textarea:focus{border-color:var(--accent);}
.form-group textarea{resize:none;min-height:70px;}
.save-btn{width:100%;background:var(--accent);color:#000;border:none;border-radius:20px;
    padding:12px;font-weight:800;font-size:.9rem;cursor:pointer;margin-top:8px;}
.close-modal{width:100%;background:#1a1a1a;color:#888;border:1px solid var(--border);
    border-radius:20px;padding:10px;cursor:pointer;margin-top:8px;font-size:.85rem;}

/* BOTTOM NAV */
.bottom-nav{position:fixed;bottom:0;width:100%;background:#111;display:flex;
    border-top:1px solid var(--border);z-index:1000;}
.bottom-nav a{flex:1;display:flex;flex-direction:column;align-items:center;padding:9px 0;
    color:var(--sub);text-decoration:none;font-size:.6rem;gap:3px;position:relative;}
.bottom-nav a.active,.bottom-nav a:hover{color:var(--accent);}
.bottom-nav a i{font-size:1.2rem;}
.bottom-nav a img{width:26px;height:26px;border-radius:50%;object-fit:cover;border:2px solid #333;}
.bottom-nav a.active img{border-color:var(--accent);}
.bottom-nav .mbadge{position:absolute;top:2px;right:14px;background:#f55;color:#fff;
    font-size:.5rem;width:13px;height:13px;border-radius:50%;display:flex;align-items:center;justify-content:center;}

/* TOAST */
.toast{position:fixed;top:70px;left:50%;transform:translateX(-50%);background:#1a1a1a;
    color:#fff;padding:9px 20px;border-radius:20px;font-size:.8rem;z-index:9999;
    border:1px solid var(--accent);opacity:0;transition:.3s;pointer-events:none;}
.toast.show{opacity:1;}
</style>
</head>
<body>

<header>
    <a href="home.php"><i class="fa fa-arrow-left"></i></a>
    <h2><?=htmlspecialchars($user['username'])?></h2>
    <?php if($is_me): ?>
    <a href="?id=<?=$my_id?>&tab=insights" style="color:var(--accent);" title="Insights"><i class="fa fa-chart-bar"></i></a>
    <?php endif; ?>
    <a href="sakon.php" class="hbadge" style="margin-left:<?=$is_me?'8':'auto'?>px;">
        <i class="fa fa-comment"></i>
        <?php if($msg_count>0):?><span class="badge"><?=$msg_count?></span><?php endif;?>
    </a>
</header>

<!-- COVER -->
<div class="cover">
    <?php if($cover): ?><img src="<?=$cover?>" onerror="this.style.display='none'"><?php endif; ?>
    <?php if($is_me): ?>
    <label class="cover-edit" title="Canja cover">
        <i class="fa fa-camera"></i> Cover
        <form id="coverForm" style="display:none;" method="POST" enctype="multipart/form-data">
            <input type="file" name="cover_pic" accept="image/*" onchange="document.getElementById('coverForm').submit()">
        </form>
    </label>
    <?php endif; ?>
    <div class="avatar-wrap">
        <img src="<?=$pic?>" id="avatarImg" onerror="this.src='assets/default.png'">
        <?php if($is_me): ?>
        <label class="avatar-edit" title="Canja hoto">
            <i class="fa fa-camera"></i>
            <form id="picForm" style="display:none;" method="POST" enctype="multipart/form-data">
                <input type="file" name="profile_pic" accept="image/*" onchange="document.getElementById('picForm').submit()">
            </form>
        </label>
        <?php endif; ?>
    </div>
</div>

<!-- PROFILE INFO -->
<div class="profile-info">
    <div class="profile-name"><?=htmlspecialchars($user['username'])?></div>
    <?php if($user['role']): ?>
    <div class="role-badge"><?=strtoupper(str_replace('_',' ',$user['role']))?></div>
    <?php endif; ?>
    <?php if($user['bio']??''): ?>
    <div class="profile-bio"><?=nl2br(htmlspecialchars($user['bio']))?></div>
    <?php endif; ?>
    <div class="profile-details">
        <?php if($user['work']??''): ?><span><i class="fa fa-briefcase"></i><?=htmlspecialchars($user['work'])?></span><?php endif; ?>
        <?php if($user['city']??''): ?><span><i class="fa fa-map-marker-alt"></i><?=htmlspecialchars($user['city'])?></span><?php endif; ?>
        <?php if($user['school']??''): ?><span><i class="fa fa-graduation-cap"></i><?=htmlspecialchars($user['school'])?></span><?php endif; ?>
    </div>
</div>

<!-- STATS -->
<div class="stats-row">
    <div class="stat-item"><div class="stat-num"><?=$posts_c?></div><div class="stat-lbl">Posts</div></div>
    <div class="stat-item" onclick="showFollowers()"><div class="stat-num"><?=$followers?></div><div class="stat-lbl">Mabiya</div></div>
    <div class="stat-item" onclick="showFollowing()"><div class="stat-num"><?=$following?></div><div class="stat-lbl">Biyo</div></div>
</div>

<!-- ACTION BUTTONS -->
<div class="action-row">
    <?php if($is_me): ?>
        <button class="btn btn-primary" onclick="openEdit()"><i class="fa fa-pen"></i> Gyara Profile</button>
        <a href="logout.php" class="btn btn-danger"><i class="fa fa-sign-out-alt"></i> Fita</a>
    <?php else: ?>
        <button class="btn <?=$i_follow?'btn-outline':'btn-primary'?>" id="follow-btn"
                onclick="toggleFollow()">
            <?=$i_follow?'<i class="fa fa-check"></i> Biyo':'<i class="fa fa-user-plus"></i> Bi'?>
        </button>
        <a href="sakon.php?to=<?=$profile_id?>" class="btn btn-outline">
            <i class="fa fa-comment"></i> Saƙo
        </a>
        <button class="btn btn-call" onclick="startCall('voice')">
            <i class="fa fa-phone" style="color:#2ecc71;"></i>
        </button>
        <button class="btn btn-call" onclick="startCall('video')">
            <i class="fa fa-video" style="color:var(--accent);"></i>
        </button>
    <?php endif; ?>
</div>

<!-- TABS -->
<div class="tabs">
    <div class="tab active" onclick="switchTab('posts',this)"><i class="fa fa-th"></i> Posts</div>
    <div class="tab" onclick="switchTab('videos',this)"><i class="fa fa-play"></i> Videos</div>
    <?php if($is_me): ?>
    <div class="tab" onclick="switchTab('saved',this)"><i class="fa fa-bookmark"></i> Saved</div>
    <?php endif; ?>
</div>

<!-- POSTS GRID -->
<div class="tab-panel active" id="tab-posts">
    <?php if($posts_q->num_rows === 0): ?>
    <div class="grid-empty"><i class="fa fa-camera"></i>Babu posts tukuna.</div>
    <?php else: ?>
    <div class="posts-grid">
    <?php while($p=$posts_q->fetch_assoc()):
        $src = $p['media_url'] ? htmlspecialchars($p['media_url']) : '';
    ?>
        <div class="grid-item" onclick="openPostLightbox('<?=$src?>','<?=$p['media_type']?>')">
            <?php if($p['media_type']==='image' && $src): ?>
                <img src="<?=$src?>" loading="lazy" onerror="this.style.display='none'">
            <?php elseif($p['media_type']==='video' && $src): ?>
                <video src="<?=$src?>" preload="none"></video>
                <div class="vid-icon"><i class="fa fa-play-circle"></i></div>
            <?php else: ?>
                <div style="display:flex;align-items:center;justify-content:center;height:100%;padding:8px;font-size:.72rem;color:#666;text-align:center;">
                    <?=htmlspecialchars(mb_substr($p['content']??'',0,60))?>
                </div>
            <?php endif; ?>
            <div class="grid-stats">
                <span><i class="fa fa-heart"></i> <?=$p['like_count']?></span>
                <span><i class="fa fa-comment"></i> <?=$p['comment_count']?></span>
            </div>
        </div>
    <?php endwhile; ?>
    </div>
    <?php endif; ?>
</div>

<!-- VIDEOS TAB -->
<div class="tab-panel" id="tab-videos">
    <?php
    $vids = $conn->query("SELECT * FROM posts WHERE user_id=$profile_id AND media_type='video' AND post_type='post' ORDER BY created_at DESC LIMIT 30");
    if(!$vids||$vids->num_rows===0): ?>
    <div class="grid-empty"><i class="fa fa-film"></i>Babu videos tukuna.</div>
    <?php else: ?>
    <div class="posts-grid">
    <?php while($v=$vids->fetch_assoc()):?>
        <div class="grid-item" onclick="location.href='videos.php'">
            <video src="<?=htmlspecialchars($v['media_url'])?>" preload="none"></video>
            <div class="vid-icon"><i class="fa fa-play-circle"></i></div>
            <div class="grid-stats">
                <span><i class="fa fa-eye"></i> <?=number_format($v['view_count']??0)?></span>
                <span><i class="fa fa-heart"></i> <?=$v['likes_count']?></span>
            </div>
        </div>
    <?php endwhile; ?>
    </div>
    <?php endif; ?>
</div>

<?php if($is_me): ?>
<!-- SAVED TAB -->
<div class="tab-panel" id="tab-saved">
    <?php
    $saved = $conn->query("SELECT p.*,u.username FROM post_saves ps
        JOIN posts p ON ps.post_id=p.id
        JOIN users u ON p.user_id=u.id
        WHERE ps.user_id=$my_id ORDER BY ps.created_at DESC LIMIT 30");
    if(!$saved||$saved->num_rows===0): ?>
    <div class="grid-empty"><i class="fa fa-bookmark"></i>Babu saved posts.</div>
    <?php else: ?>
    <div class="posts-grid">
    <?php while($sv=$saved->fetch_assoc()):
        $src2 = $sv['media_url'] ? htmlspecialchars($sv['media_url']) : '';
    ?>
        <div class="grid-item">
            <?php if($sv['media_type']==='image' && $src2): ?>
                <img src="<?=$src2?>" loading="lazy">
            <?php elseif($sv['media_type']==='video' && $src2): ?>
                <video src="<?=$src2?>" preload="none"></video>
                <div class="vid-icon"><i class="fa fa-play-circle"></i></div>
            <?php else: ?>
                <div style="display:flex;align-items:center;justify-content:center;height:100%;padding:8px;font-size:.72rem;color:#666;text-align:center;">
                    <?=htmlspecialchars(mb_substr($sv['content']??'',0,60))?>
                </div>
            <?php endif; ?>
        </div>
    <?php endwhile; ?>
    </div>
    <?php endif; ?>
</div>
<?php endif; ?>

<!-- LIGHTBOX -->
<div id="lightbox" style="display:none;position:fixed;inset:0;background:rgba(0,0,0,.96);z-index:9999;
    align-items:center;justify-content:center;" onclick="closeLightbox()">
    <button style="position:absolute;top:16px;right:16px;background:none;border:none;color:#fff;font-size:1.6rem;cursor:pointer;"
        onclick="closeLightbox()"><i class="fa fa-times"></i></button>
    <div id="lb-content"></div>
</div>

<!-- EDIT PROFILE MODAL -->
<div class="modal-bg" id="edit-modal">
    <div class="modal">
        <h3><i class="fa fa-pen"></i> Gyara Profile</h3>
        <form method="POST" enctype="multipart/form-data">
            <input type="hidden" name="edit_profile" value="1">
            <div class="form-group">
                <label>Username</label>
                <input type="text" name="username" value="<?=htmlspecialchars($user['username']??'')?>" required>
            </div>
            <div class="form-group">
                <label>Bio</label>
                <textarea name="bio"><?=htmlspecialchars($user['bio']??'')?></textarea>
            </div>
            <div class="form-group">
                <label>Aiki (Work)</label>
                <input type="text" name="work" value="<?=htmlspecialchars($user['work']??'')?>">
            </div>
            <div class="form-group">
                <label>Makarantar (School)</label>
                <input type="text" name="school" value="<?=htmlspecialchars($user['school']??'')?>">
            </div>
            <div class="form-group">
                <label>Birni (City)</label>
                <input type="text" name="city" value="<?=htmlspecialchars($user['city']??'')?>">
            </div>
            <button type="submit" class="save-btn">Adana Canje-canje</button>
        </form>
        <button class="close-modal" onclick="closeEdit()">Soke</button>
    </div>
</div>

<!-- BOTTOM NAV -->
<nav class="bottom-nav">
    <a href="home.php"><i class="fa fa-home"></i><span>Gida</span></a>
    <a href="videos.php"><i class="fa fa-play-circle"></i><span>Videos</span></a>
    <a href="sakon.php" style="position:relative;">
        <i class="fa fa-comment"></i>
        <?php if($msg_count>0):?><span class="mbadge"><?=$msg_count?></span><?php endif;?>
        <span>Sako</span>
    </a>
    <a href="home.php"><i class="fa fa-bell"></i>
        <?php if($notif_count>0):?><span class="mbadge"><?=$notif_count?></span><?php endif;?>
        <span>Sanarwa</span></a>
    <a href="profile.php?id=<?=$my_id?>" class="active">
        <img src="<?=$me['profile_pic']?'uploads/'.$me['profile_pic']:''?>" onerror="this.src='assets/default.png'">
        <span>Ni</span>
    </a>
</nav>

<div class="toast" id="toast"></div>

<script>
const PROFILE_ID = <?=$profile_id?>;
const MY_ID      = <?=$my_id?>;
let isFollowing  = <?=$i_follow?'true':'false'?>;

function switchTab(name, el) {
    document.querySelectorAll('.tab').forEach(t => t.classList.remove('active'));
    document.querySelectorAll('.tab-panel').forEach(p => p.classList.remove('active'));
    el.classList.add('active');
    document.getElementById('tab-' + name)?.classList.add('active');
}

function openEdit()  { document.getElementById('edit-modal').classList.add('open'); }
function closeEdit() { document.getElementById('edit-modal').classList.remove('open'); }
document.getElementById('edit-modal').addEventListener('click', e => {
    if (e.target === document.getElementById('edit-modal')) closeEdit();
});

async function toggleFollow() {
    const btn = document.getElementById('follow-btn');
    const r   = await fetch('profile.php?id=' + PROFILE_ID, {
        method:'POST', headers:{'Content-Type':'application/x-www-form-urlencoded'},
        body:`action=follow&follow_id=${PROFILE_ID}`});
    const d = await r.json();
    isFollowing = d.followed;
    if (d.followed) {
        btn.innerHTML = '<i class="fa fa-check"></i> Biyo';
        btn.className = 'btn btn-outline';
    } else {
        btn.innerHTML = '<i class="fa fa-user-plus"></i> Bi';
        btn.className = 'btn btn-primary';
    }
    showToast(d.followed ? 'Ka biyo!' : 'An cire biyo');
}

function startCall(type) {
    window.location.href = `call.php?to=${PROFILE_ID}&type=${type}`;
}

function openPostLightbox(src, type) {
    if (!src) return;
    const lb = document.getElementById('lightbox');
    const cnt = document.getElementById('lb-content');
    lb.style.display = 'flex';
    if (type === 'image') {
        cnt.innerHTML = `<img src="${src}" style="max-width:96%;max-height:96vh;object-fit:contain;border-radius:8px;" onclick="event.stopPropagation()">`;
    } else if (type === 'video') {
        cnt.innerHTML = `<video src="${src}" controls autoplay style="max-width:96%;max-height:96vh;border-radius:8px;" onclick="event.stopPropagation()"></video>`;
    }
}
function closeLightbox() {
    document.getElementById('lightbox').style.display = 'none';
    document.getElementById('lb-content').innerHTML = '';
}

function showFollowers() {
    window.location.href = `followers.php?id=${PROFILE_ID}&type=followers`;
}
function showFollowing() {
    window.location.href = `followers.php?id=${PROFILE_ID}&type=following`;
}

function showToast(msg) {
    const t = document.getElementById('toast');
    t.textContent = msg; t.classList.add('show');
    setTimeout(() => t.classList.remove('show'), 2200);
}

<?php if(isset($_GET['saved'])): ?>
showToast('✅ Profile an adana!');
<?php endif; ?>
</script>
</body>
</html>
