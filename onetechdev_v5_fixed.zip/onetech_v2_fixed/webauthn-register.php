<?php
require_once 'inc/config.php';
header('Content-Type: application/json');

$data   = json_decode(file_get_contents('php://input'), true);
$email  = $conn->real_escape_string(trim($data['email'] ?? ''));
$credId = $conn->real_escape_string($data['id'] ?? '');

if (!$email || !$credId) {
    echo json_encode(['success'=>false,'message'=>'Bayanai sun kasa']); exit;
}

// Check user exists
$user = $conn->query("SELECT id FROM users WHERE email='$email'")->fetch_assoc();
if (!$user) {
    echo json_encode(['success'=>false,'message'=>'Ba a sami wannan email ba. Da farko ka register da password']); exit;
}

// Save credential_id
$conn->query("UPDATE users SET credential_id='$credId' WHERE email='$email'");
echo json_encode(['success'=>true]);
