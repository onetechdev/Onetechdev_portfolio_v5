<?php
require_once 'inc/config.php';
if (!isLoggedIn()) exit;

$viewer_id = $_SESSION['user_id'];

// Handle story creation
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_FILES['story_media'])) {
    $file = $_FILES['story_media'];
    if ($file['error'] === 0) {
        $ext = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
        $img_ext = ['jpg','jpeg','png','gif','webp'];
        $vid_ext = ['mp4','webm','mov'];
        $fn  = 'story_'.uniqid().'.'.$ext;
        $dst = 'uploads/'.$fn;
        move_uploaded_file($file['tmp_name'], $dst);
        $expires = date('Y-m-d H:i:s', strtotime('+24 hours'));
        $col = in_array($ext, $img_ext) ? 'image' : 'video';
        $conn->query("INSERT INTO stories (user_id,{$col},expires_at) VALUES ($viewer_id,'$fn','$expires')");
    }
    echo json_encode(['ok'=>true]); exit;
}

// Handle mark as seen
if (isset($_GET['seen'])) {
    $sid = (int)$_GET['seen'];
    $conn->query("INSERT IGNORE INTO story_views_v2 (story_id,viewer_id) VALUES ($sid,$viewer_id)");
    $conn->query("UPDATE stories SET view_count=view_count+1 WHERE id=$sid");
    exit;
}

// Fetch stories (from followed users + own), not yet seen
$q = $conn->query("
    SELECT s.*, u.username, u.profile_pic,
        TIMESTAMPDIFF(MINUTE, s.created_at, NOW()) AS minutes_ago,
        (SELECT COUNT(*) FROM story_views_v2 WHERE story_id=s.id AND viewer_id=$viewer_id) AS is_seen
    FROM stories s
    JOIN users u ON s.user_id = u.id
    WHERE s.expires_at > NOW()
      AND (s.user_id = $viewer_id
           OR s.user_id IN (SELECT following_id FROM follows WHERE follower_id=$viewer_id))
    ORDER BY is_seen ASC, s.created_at DESC
    LIMIT 30
");

$stories = [];
while ($s = $q->fetch_assoc()) {
    $m = (int)$s['minutes_ago'];
    $ago = $m < 60 ? $m.'m' : floor($m/60).'h';
    $stories[] = [
        'id'          => (int)$s['id'],
        'user_id'     => (int)$s['user_id'],
        'firstname'   => $s['username'],
        'lastname'    => '',
        'profile_pic' => $s['profile_pic'] ? 'uploads/'.htmlspecialchars($s['profile_pic']) : 'assets/default.png',
        'src'         => $s['image'] ? 'uploads/'.$s['image'] : 'uploads/'.$s['video'],
        'type'        => $s['image'] ? 'image' : 'video',
        'time_ago'    => $ago,
        'seen'        => (bool)$s['is_seen'],
        'views'       => (int)$s['view_count'],
    ];
}

header('Content-Type: application/json');
echo json_encode($stories);
