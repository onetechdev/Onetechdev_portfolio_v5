<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);
session_start();

// Database Connection
$host = "sql306.infinityfree.com";
$user = "if0_41978391";
$pass = "hAnbfH7JEtg98";
$db   = "if0_41978391_onetechdev";

$conn = new mysqli($host, $user, $pass, $db);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
$conn->set_charset("utf8mb4");

// PHPMailer Config
define('MAIL_HOST',     'smtp.gmail.com');
define('MAIL_PORT',     587);
define('MAIL_USERNAME', 'usmanmannir137@gmail.com');
define('MAIL_PASSWORD', 'vhvlsszitnfmsvqe');
define('MAIL_FROM',     'usmanmannir137@gmail.com');
define('MAIL_NAME',     'Onetech Dev');
define('SITE_URL',      'https://onetechdev.gt.tc');

// Helper: Check login
function isLoggedIn() {
    return isset($_SESSION['user_id']);
}

// Helper: Redirect
function redirect($url) {
    header("Location: $url");
    exit();
}

// Helper: Sanitize
function clean($conn, $str) {
    return $conn->real_escape_string(htmlspecialchars(trim($str)));
}
?>