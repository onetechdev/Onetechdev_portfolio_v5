<?php
require_once '../inc/config.php';

// Check admin — first user or role check
$admin = $conn->query("SELECT * FROM users WHERE id={$_SESSION['user_id']}")->fetch_assoc();
if (!isLoggedIn() || $admin['id'] !== 1) {
    // Change '1' to your admin user ID
    redirect('../index.php');
}

// ── HANDLE: Send Broadcast Notification ──────────────────────────────
if ($_SERVER['REQUEST_METHOD']==='POST' && isset($_POST['send_broadcast'])) {
    $msg     = clean($conn, $_POST['broadcast_msg'] ?? '');
    $target  = $_POST['target'] ?? 'all'; // 'all' or specific role
    $send_email = isset($_POST['send_email']);

    if (!empty($msg)) {
        // Get target users
        if ($target === 'all') {
            $ulist = $conn->query("SELECT id,email,username FROM users WHERE id != {$admin['id']}");
        } else {
            $role = clean($conn, $target);
            $ulist = $conn->query("SELECT id,email,username FROM users WHERE role='$role' AND id != {$admin['id']}");
        }

        // PHPMailer setup if needed
        if ($send_email) {
            use PHPMailer\PHPMailer\PHPMailer;
            use PHPMailer\PHPMailer\Exception;
            require '../scr/PHPMailer.php';
            require '../scr/SMTP.php';
            require '../scr/Exception.php';
        }

        $sent = 0;
        while ($u = $ulist->fetch_assoc()) {
            // DB Notification
            $conn->query("INSERT INTO notifications (user_id, from_user_id, type, message)
                          VALUES ({$u['id']}, {$admin['id']}, 'message', '$msg')");

            // Email
            if ($send_email) {
                try {
                    $mail = new PHPMailer(true);
                    $mail->isSMTP();
                    $mail->Host       = MAIL_HOST;
                    $mail->SMTPAuth   = true;
                    $mail->Username   = MAIL_USERNAME;
                    $mail->Password   = MAIL_PASSWORD;
                    $mail->SMTPSecure = 'tls';
                    $mail->Port       = MAIL_PORT;
                    $mail->setFrom(MAIL_FROM, MAIL_NAME);
                    $mail->addAddress($u['email'], $u['username']);
                    $mail->isHTML(true);
                    $mail->Subject = "📢 Saƙo daga Onetech Dev Admin";
                    $mail->Body = "
                    <div style='font-family:Poppins,sans-serif;background:#111;color:white;padding:30px;border-radius:10px;max-width:600px;'>
                        <h2 style='color:#00d4ff;'>📢 Onetech Dev</h2>
                        <p>Sannu <strong>{$u['username']}</strong>,</p>
                        <div style='background:#1a1a1a;border-left:4px solid #00d4ff;padding:15px 20px;border-radius:0 8px 8px 0;margin:15px 0;'>
                            <p style='color:#ddd;'>" . nl2br(htmlspecialchars($msg)) . "</p>
                        </div>
                        <p style='color:#aaa;font-size:0.85rem;'>Onetech Dev Community</p>
                    </div>";
                    $mail->send();
                    $sent++;
                } catch (Exception $e) { /* skip */ }
            } else {
                $sent++;
            }
        }
        $successMsg = "✅ An aika saƙo ga $sent user(s)";
    }
}

// ── HANDLE: Send to Specific User ────────────────────────────────────
if ($_SERVER['REQUEST_METHOD']==='POST' && isset($_POST['send_single'])) {
    $to_uid  = (int)$_POST['to_user'];
    $subject = clean($conn, $_POST['subject'] ?? '');
    $msg     = clean($conn, $_POST['single_msg'] ?? '');
    $role_update = clean($conn, $_POST['new_role'] ?? '');

    // Update role if provided
    if (!empty($role_update)) {
        $allowed = ['developer','programmer','backend_dev','frontend_dev','server_security'];
        if (in_array($role_update, $allowed)) {
            $conn->query("UPDATE users SET role='$role_update' WHERE id=$to_uid");
        }
    }

    // DB notification
    if (!empty($msg)) {
        $conn->query("INSERT INTO notifications (user_id, from_user_id, type, message)
                      VALUES ($to_uid, {$admin['id']}, 'message', '$msg')");

        // Send email
        $toUser = $conn->query("SELECT * FROM users WHERE id=$to_uid")->fetch_assoc();
        if ($toUser) {
            use PHPMailer\PHPMailer\PHPMailer;
            use PHPMailer\PHPMailer\Exception;
            require '../scr/PHPMailer.php';
            require '../scr/SMTP.php';
            require '../scr/Exception.php';
            try {
                $mail = new PHPMailer(true);
                $mail->isSMTP();
                $mail->Host=MAIL_HOST; $mail->SMTPAuth=true;
                $mail->Username=MAIL_USERNAME; $mail->Password=MAIL_PASSWORD;
                $mail->SMTPSecure='tls'; $mail->Port=MAIL_PORT;
                $mail->setFrom(MAIL_FROM, MAIL_NAME);
                $mail->addAddress($toUser['email'], $toUser['username']);
                $mail->isHTML(true);
                $mail->Subject = !empty($subject) ? $subject : "📬 Saƙo daga Onetech Dev";
                $mail->Body = "
                <div style='font-family:Poppins,sans-serif;background:#111;color:white;padding:30px;border-radius:10px;max-width:600px;'>
                    <h2 style='color:#00d4ff;'>📬 Onetech Dev</h2>
                    <p>Sannu <strong>{$toUser['username']}</strong>,</p>
                    <div style='background:#1a1a1a;border-left:4px solid #00d4ff;padding:15px 20px;border-radius:0 8px 8px 0;margin:15px 0;'>
                        <p style='color:#ddd;'>" . nl2br(htmlspecialchars($msg)) . "</p>
                    </div>
                    " . (!empty($role_update) ? "<p style='color:#0f0;'>✅ Role dinka an sabunta zuwa: <strong>$role_update</strong></p>" : "") . "
                    <p style='color:#aaa;font-size:0.85rem;'>Onetech Dev Community</p>
                </div>";
                $mail->send();
                $successMsg = "✅ An aika saƙo ga {$toUser['username']}";
            } catch (Exception $e) {
                $successMsg = "⚠️ Notification an aika amma email ya kasa: ".$e->getMessage();
            }
        }
    }
}

// ── HANDLE: Delete User ───────────────────────────────────────────────
if ($_SERVER['REQUEST_METHOD']==='POST' && isset($_POST['delete_user'])) {
    $del_id = (int)$_POST['del_id'];
    if ($del_id !== $admin['id']) {
        $conn->query("DELETE FROM users WHERE id=$del_id");
        $successMsg = "✅ User an share";
    }
}

// ── STATS ─────────────────────────────────────────────────────────────
$totalUsers  = $conn->query("SELECT COUNT(*) as c FROM users")->fetch_assoc()['c'];
$totalPosts  = $conn->query("SELECT COUNT(*) as c FROM posts WHERE post_type='post'")->fetch_assoc()['c'];
$totalMsgs   = $conn->query("SELECT COUNT(*) as c FROM messages")->fetch_assoc()['c'];
$totalGroups = $conn->query("SELECT COUNT(*) as c FROM group_chats")->fetch_assoc()['c'];

// Role counts
$roleCounts = [];
$rc=$conn->query("SELECT role, COUNT(*) as c FROM users GROUP BY role");
while($r=$rc->fetch_assoc()) $roleCounts[$r['role']]=$r['c'];

// All users list
$allUsers = $conn->query("SELECT * FROM users ORDER BY created_at DESC");
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Admin Panel - Onetech Dev</title>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
<style>
@import url('https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;600;800&display=swap');
*{margin:0;padding:0;box-sizing:border-box;font-family:'Poppins',sans-serif;}
body{background:#080808;color:white;min-height:100vh;display:flex;}

/* ADMIN SIDEBAR */
.admin-sidebar{
    width:220px;background:#0d0d0d;border-right:1px solid #1a1a1a;
    display:flex;flex-direction:column;min-height:100vh;flex-shrink:0;
    position:sticky;top:0;height:100vh;
}
.admin-logo{padding:20px;color:#00d4ff;font-weight:800;font-size:1.2rem;
    border-bottom:1px solid #1a1a1a;display:flex;align-items:center;gap:10px;}
.admin-nav a{
    display:flex;align-items:center;gap:12px;padding:13px 20px;color:#666;
    text-decoration:none;transition:0.3s;font-size:0.9rem;border-left:3px solid transparent;
}
.admin-nav a:hover,.admin-nav a.active{color:#00d4ff;background:rgba(0,212,255,0.05);border-left-color:#00d4ff;}
.admin-nav a i{width:18px;text-align:center;}
.admin-sidebar .logout{margin-top:auto;padding:15px 20px;border-top:1px solid #1a1a1a;}
.admin-sidebar .logout a{color:#f55;text-decoration:none;font-size:0.85rem;display:flex;align-items:center;gap:8px;}

/* MAIN */
.admin-main{flex:1;padding:30px;overflow-y:auto;}
.admin-header{display:flex;justify-content:space-between;align-items:center;margin-bottom:30px;}
.admin-header h1{font-size:1.5rem;}
.admin-header span{color:#aaa;font-size:0.85rem;}

/* STATS GRID */
.stats-grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(180px,1fr));gap:15px;margin-bottom:30px;}
.stat-card{background:#111;border:1px solid #1a1a1a;border-radius:12px;padding:20px;transition:0.3s;}
.stat-card:hover{border-color:#00d4ff;}
.stat-card .icon{font-size:2rem;margin-bottom:10px;}
.stat-card .val{font-size:1.8rem;font-weight:800;color:#00d4ff;}
.stat-card .lbl{color:#666;font-size:0.8rem;margin-top:3px;}

/* SECTIONS */
.admin-section{background:#111;border:1px solid #1a1a1a;border-radius:15px;padding:25px;margin-bottom:25px;}
.admin-section h3{color:#00d4ff;margin-bottom:20px;display:flex;align-items:center;gap:10px;font-size:1rem;}
.success-msg{background:rgba(0,255,0,0.1);border:1px solid #0f0;color:#0f0;padding:12px 18px;
    border-radius:8px;margin-bottom:20px;font-size:0.9rem;}

/* FORM STYLES */
.aform label{display:block;color:#aaa;font-size:0.8rem;margin-bottom:5px;margin-top:12px;}
.aform input,.aform textarea,.aform select{
    width:100%;background:#1a1a1a;border:1px solid #333;border-radius:8px;
    color:white;padding:10px 14px;outline:none;font-size:0.9rem;transition:0.3s;
}
.aform input:focus,.aform textarea:focus,.aform select:focus{border-color:#00d4ff;}
.aform select option{background:#111;}
.aform .row{display:grid;grid-template-columns:1fr 1fr;gap:15px;}
.aform-btns{display:flex;gap:10px;margin-top:20px;}
.abtn{padding:10px 22px;border-radius:8px;border:none;cursor:pointer;font-weight:600;font-size:0.9rem;transition:0.3s;}
.abtn-primary{background:#00d4ff;color:#000;}
.abtn-primary:hover{opacity:0.9;}
.abtn-secondary{background:#333;color:#ccc;}
.abtn-secondary:hover{background:#444;}
.abtn-danger{background:#f55;color:white;}
.abtn-danger:hover{background:#d44;}

/* ROLE BADGES */
.role-pills{display:flex;flex-wrap:wrap;gap:8px;margin-bottom:15px;}
.rpill{padding:6px 16px;border-radius:20px;border:2px solid #333;background:transparent;
    color:#666;cursor:pointer;font-size:0.8rem;transition:0.3s;}
.rpill.active{border-color:#00d4ff;color:#00d4ff;background:rgba(0,212,255,0.1);}

/* USERS TABLE */
.users-table{width:100%;border-collapse:collapse;font-size:0.85rem;}
.users-table th{padding:10px 15px;text-align:left;color:#aaa;border-bottom:1px solid #222;font-weight:500;}
.users-table td{padding:12px 15px;border-bottom:1px solid #1a1a1a;vertical-align:middle;}
.users-table tr:hover td{background:rgba(255,255,255,0.02);}
.users-table img{width:36px;height:36px;border-radius:50%;object-fit:cover;border:2px solid #333;}
.role-badge-sm{background:rgba(0,212,255,0.12);color:#00d4ff;padding:3px 10px;
    border-radius:20px;font-size:0.75rem;white-space:nowrap;}
.tbl-actions{display:flex;gap:8px;}
.tbl-actions button{padding:5px 12px;border:none;border-radius:6px;cursor:pointer;font-size:0.78rem;transition:0.3s;}
.btn-msg-sm{background:rgba(0,212,255,0.15);color:#00d4ff;}
.btn-del-sm{background:rgba(255,85,85,0.15);color:#f55;}
.btn-msg-sm:hover{background:#00d4ff;color:#000;}
.btn-del-sm:hover{background:#f55;color:white;}

/* SEARCH */
.table-search{margin-bottom:15px;}
.table-search input{background:#1a1a1a;border:1px solid #333;border-radius:20px;
    padding:8px 16px;color:white;outline:none;font-size:0.85rem;width:100%;max-width:300px;}
.table-search input:focus{border-color:#00d4ff;}
</style>
</head>
<body>

<!-- ADMIN SIDEBAR -->
<div class="admin-sidebar">
    <div class="admin-logo"><i class="fa fa-shield-halved"></i> Admin</div>
    <nav class="admin-nav">
        <a href="#stats" class="active"><i class="fa fa-chart-bar"></i> Dashboard</a>
        <a href="#broadcast"><i class="fa fa-bullhorn"></i> Broadcast</a>
        <a href="#single-msg"><i class="fa fa-envelope"></i> Direct Message</a>
        <a href="#users"><i class="fa fa-users"></i> Users</a>
        <a href="../feed.php"><i class="fa fa-home"></i> View Site</a>
    </nav>
    <div class="logout"><a href="../logout.php"><i class="fa fa-sign-out-alt"></i> Logout</a></div>
</div>

<!-- MAIN CONTENT -->
<div class="admin-main">
    <div class="admin-header">
        <h1><i class="fa fa-shield-halved" style="color:#00d4ff;"></i> Admin Panel</h1>
        <span>Welcome, <?=$admin['username']?> | <?=date('d M Y')?></span>
    </div>

    <?php if(!empty($successMsg)): ?>
    <div class="success-msg"><i class="fa fa-check-circle"></i> <?=$successMsg?></div>
    <?php endif; ?>

    <!-- STATS -->
    <div id="stats" class="stats-grid">
        <div class="stat-card">
            <div class="icon">👥</div>
            <div class="val"><?=$totalUsers?></div>
            <div class="lbl">Total Users</div>
        </div>
        <div class="stat-card">
            <div class="icon">📝</div>
            <div class="val"><?=$totalPosts?></div>
            <div class="lbl">Total Posts</div>
        </div>
        <div class="stat-card">
            <div class="icon">💬</div>
            <div class="val"><?=$totalMsgs?></div>
            <div class="lbl">Messages Sent</div>
        </div>
        <div class="stat-card">
            <div class="icon">👾</div>
            <div class="val"><?=$totalGroups?></div>
            <div class="lbl">Group Chats</div>
        </div>
    </div>

    <!-- ROLE BREAKDOWN -->
    <div class="admin-section">
        <h3><i class="fa fa-chart-pie"></i> Users by Role</h3>
        <div class="role-pills">
            <?php
            $allRoles=['developer','programmer','backend_dev','frontend_dev','server_security'];
            foreach($allRoles as $r):
                $c=$roleCounts[$r]??0;
            ?>
            <span class="rpill active">
                <?=str_replace('_',' ',ucfirst($r))?> <strong style="color:#00d4ff;">(<?=$c?>)</strong>
            </span>
            <?php endforeach; ?>
        </div>
    </div>

    <!-- ── BROADCAST ─────────────────────────────────────── -->
    <div id="broadcast" class="admin-section">
        <h3><i class="fa fa-bullhorn"></i> Broadcast Message (Aika GA Duk Users)</h3>
        <form method="POST" class="aform">
            <input type="hidden" name="send_broadcast" value="1">

            <label>Zaɓi Target (Wa za a aika):</label>
            <select name="target">
                <option value="all">🌐 Duk Users</option>
                <option value="developer">Developers</option>
                <option value="programmer">Programmers</option>
                <option value="backend_dev">Backend Devs</option>
                <option value="frontend_dev">Frontend Devs</option>
                <option value="server_security">Server Security</option>
            </select>

            <label>Saƙo:</label>
            <textarea name="broadcast_msg" rows="4"
                placeholder="Rubuta saƙon da za a aika wa duk users..." required></textarea>

            <div style="margin-top:12px;display:flex;align-items:center;gap:10px;">
                <input type="checkbox" name="send_email" id="send_email" style="width:auto;accent-color:#00d4ff;">
                <label for="send_email" style="margin:0;color:#ccc;font-size:0.9rem;">
                    Kuma aika wa email (PHPMailer)
                </label>
            </div>

            <div class="aform-btns">
                <button type="submit" class="abtn abtn-primary">
                    <i class="fa fa-paper-plane"></i> Aika Broadcast
                </button>
            </div>
        </form>
    </div>

    <!-- ── SINGLE USER MESSAGE ───────────────────────────── -->
    <div id="single-msg" class="admin-section">
        <h3><i class="fa fa-envelope"></i> Aika Saƙo / Update Role (Specific User)</h3>
        <form method="POST" class="aform">
            <input type="hidden" name="send_single" value="1">

            <div class="row">
                <div>
                    <label>Zaɓi User:</label>
                    <select name="to_user" required>
                        <option value="">-- Zaɓi User --</option>
                        <?php
                        $conn->query("SELECT 1"); // reset
                        $ul=$conn->query("SELECT id,username,role FROM users WHERE id!={$admin['id']} ORDER BY username");
                        while($u=$ul->fetch_assoc()):
                        ?>
                        <option value="<?=$u['id']?>"><?=$u['username']?> (<?=str_replace('_',' ',$u['role'])?>)</option>
                        <?php endwhile; ?>
                    </select>
                </div>
                <div>
                    <label>Sabunta Role (optional):</label>
                    <select name="new_role">
                        <option value="">-- Kada a canza --</option>
                        <option value="developer">Developer</option>
                        <option value="programmer">Programmer</option>
                        <option value="backend_dev">Backend Dev</option>
                        <option value="frontend_dev">Frontend Dev</option>
                        <option value="server_security">Server Security</option>
                    </select>
                </div>
            </div>

            <label>Subject na Email (optional):</label>
            <input type="text" name="subject" placeholder="Misali: Barka da matsayin sabon...">

            <label>Saƙo:</label>
            <textarea name="single_msg" rows="5"
                placeholder="Rubuta saƙo ga wannan user... misali: Barka da zuwa, an baka matsayin Senior Developer a Onetech Community!" required></textarea>

            <div class="aform-btns">
                <button type="submit" class="abtn abtn-primary">
                    <i class="fa fa-paper-plane"></i> Aika Saƙo + Email
                </button>
            </div>
        </form>
    </div>

    <!-- ── USERS TABLE ────────────────────────────────────── -->
    <div id="users" class="admin-section">
        <h3><i class="fa fa-users"></i> Duk Users (<?=$totalUsers?>)</h3>
        <div class="table-search">
            <input type="text" id="user-search" placeholder="Neman user..." oninput="filterUsers()">
        </div>
        <div style="overflow-x:auto;">
        <table class="users-table">
            <thead>
                <tr>
                    <th>#</th>
                    <th>User</th>
                    <th>Email</th>
                    <th>Role</th>
                    <th>Joined</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody id="users-tbody">
            <?php $allUsers->data_seek(0); while($u=$allUsers->fetch_assoc()): ?>
            <tr id="urow-<?=$u['id']?>">
                <td style="color:#555;"><?=$u['id']?></td>
                <td>
                    <div style="display:flex;align-items:center;gap:10px;">
                        <img src="<?=$u['profile_pic']?>" alt="">
                        <div>
                            <strong><?=htmlspecialchars($u['username'])?></strong>
                            <?php if($u['is_verified']): ?><i class="fa fa-circle-check" style="color:#00d4ff;font-size:0.7rem;"></i><?php endif; ?>
                        </div>
                    </div>
                </td>
                <td style="color:#888;"><?=htmlspecialchars($u['email'])?></td>
                <td><span class="role-badge-sm"><?=str_replace('_',' ',ucfirst($u['role']))?></span></td>
                <td style="color:#666;"><?=date('d M Y',strtotime($u['created_at']))?></td>
                <td>
                    <div class="tbl-actions">
                        <button class="btn-msg-sm" onclick="quickMsg(<?=$u['id']?>,'<?=htmlspecialchars($u['username'])?>')">
                            <i class="fa fa-envelope"></i> Msg
                        </button>
                        <?php if($u['id']!==$admin['id']): ?>
                        <form method="POST" style="display:inline;" onsubmit="return confirm('Ka tabbata kana son share wannan user?')">
                            <input type="hidden" name="delete_user" value="1">
                            <input type="hidden" name="del_id" value="<?=$u['id']?>">
                            <button type="submit" class="btn-del-sm"><i class="fa fa-trash"></i></button>
                        </form>
                        <?php endif; ?>
                    </div>
                </td>
            </tr>
            <?php endwhile; ?>
            </tbody>
        </table>
        </div>
    </div>
</div>

<script>
// Filter users table
function filterUsers(){
    const q=document.getElementById('user-search').value.toLowerCase();
    document.querySelectorAll('#users-tbody tr').forEach(row=>{
        row.style.display=row.textContent.toLowerCase().includes(q)?'':'none';
    });
}

// Quick message — scroll to single msg and prefill
function quickMsg(uid, uname){
    document.getElementById('single-msg').scrollIntoView({behavior:'smooth'});
    const sel=document.querySelector('select[name="to_user"]');
    sel.value=uid;
    document.querySelector('textarea[name="single_msg"]').focus();
}

// Nav active highlight
document.querySelectorAll('.admin-nav a').forEach(a=>{
    a.addEventListener('click',()=>{
        document.querySelectorAll('.admin-nav a').forEach(x=>x.classList.remove('active'));
        a.classList.add('active');
    });
});
</script>
</body>
</html>