<?php require_once 'inc/config.php'; ?>
<!DOCTYPE html>
<html lang="ha">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Onetech Dev</title>
<meta name="description" content="Professional Software Developer specializing in Web Development, AI Solutions, and Business Applications.">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
<style>
@import url('https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;600;800&display=swap');
*{margin:0;padding:0;box-sizing:border-box;font-family:'Poppins',sans-serif;}
body{background:url('background.jpg') no-repeat center center/cover fixed;color:white;overflow-x:hidden;}
.background-overlay{position:fixed;top:0;left:0;width:100%;height:100%;background:rgba(0,0,0,0.7);z-index:-1;}

/* NAV */
nav{position:sticky;top:0;display:flex;justify-content:space-between;padding:8px 3%;align-items:center;background:rgba(0,0,0,0.6);backdrop-filter:blur(10px);z-index:1000;border-bottom:1px solid rgba(255,255,255,0.1);}
.logo{font-size:1.5rem;font-weight:800;color:#00d4ff;}
nav ul{display:flex;list-style:none;}
nav ul li{margin-left:20px;}
nav ul li a{color:white;text-decoration:none;font-weight:500;}

/* HAMBURGER */
.hamburger{display:none;flex-direction:column;gap:5px;cursor:pointer;background:none;border:none;padding:4px;}
.hamburger span{width:24px;height:2px;background:white;border-radius:2px;transition:0.3s;}
.hamburger.open span:nth-child(1){transform:rotate(45deg) translate(5px,5px);}
.hamburger.open span:nth-child(2){opacity:0;}
.hamburger.open span:nth-child(3){transform:rotate(-45deg) translate(5px,-5px);}

@media(max-width:768px){
    .hamburger{display:flex;}
    nav ul{
        display:none;flex-direction:column;
        position:fixed;top:55px;left:0;right:0;
        background:rgba(0,0,0,0.95);
        padding:20px;gap:5px;z-index:999;
    }
    nav ul.open{display:flex;}
    nav ul li{margin-left:0;}
    nav ul li a{display:block;padding:12px 10px;border-bottom:1px solid rgba(255,255,255,0.08);font-size:1rem;}
    .hero h1{font-size:2rem;}
    .hero p{font-size:0.95rem;}
}

/* HERO */
.hero{height:90vh;display:flex;align-items:center;justify-content:center;text-align:center;padding:0 20px;}
.hero h1{font-size:3.5rem;margin-bottom:10px;}
.highlight{color:#00d4ff;text-shadow:0 0 10px #00d4ff,0 0 20px #00d4ff;animation:pulse 2s infinite;}
@keyframes pulse{0%{opacity:1;}50%{opacity:0.7;}100%{opacity:1;}}
.hero p{font-size:1.2rem;color:#ccc;max-width:700px;margin-bottom:30px;}
.btn-primary{background:#00d4ff;padding:12px 30px;border-radius:5px;color:#000;text-decoration:none;font-weight:bold;margin-right:10px;transition:0.3s;}
.btn-primary:hover{background:green;box-shadow:0 0 20px #00d4ff;transform:scale(1.05);}
.btn-secondary{background:transparent;border:2px solid #00d4ff;padding:12px 30px;border-radius:5px;color:#00d4ff;text-decoration:none;font-weight:bold;transition:0.3s;}
.btn-secondary:hover{background:green;transform:translateY(-2px);}

/* PROFILE */
.profile-container{position:relative;width:180px;height:180px;margin:0 auto 25px;}
.profile-img{width:100%;height:100%;object-fit:cover;border-radius:50%;border:4px solid #00d4ff;box-shadow:0 0 20px rgba(0,212,255,0.6);transition:0.5s;}
.profile-img:hover{transform:rotate(5deg) scale(1.1);}
.profile-container::before{content:'';position:absolute;top:-10px;left:-10px;right:-10px;bottom:-10px;border:2px dashed rgba(0,212,255,0.5);border-radius:50%;animation:rotate-border 10s linear infinite;}
@keyframes rotate-border{from{transform:rotate(0deg);}to{transform:rotate(360deg);}}

/* SECTIONS */
.skills{padding:40px 10%;text-align:center;}
.skills-container{display:flex;justify-content:center;gap:30px;flex-wrap:wrap;}
.skill-item{display:flex;flex-direction:column;align-items:center;color:#ccc;transition:0.4s;animation:float 3s ease-in-out infinite;}
.skill-item i{font-size:2.5rem;margin-bottom:10px;}
.skill-item:hover{color:#00d4ff;transform:translateY(-10px);}
@keyframes float{0%,100%{transform:translateY(0);}50%{transform:translateY(-5px);}}
.about,.services,.projects,.carousel-section,.why-me,.contact{padding:80px 10%;text-align:center;}
.grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(250px,1fr));gap:20px;margin-top:40px;}
.card{background:rgba(255,255,255,0.1);padding:30px;border-radius:15px;backdrop-filter:blur(10px);border:1px solid rgba(255,255,255,0.1);transition:0.3s;}
.card:hover{transform:translateY(-10px);border-color:#00d4ff;background:rgba(0,212,255,0.1);box-shadow:0 8px 32px rgba(0,212,255,0.37);}
.hidden{opacity:0;transform:translateY(50px);transition:all 0.8s ease-out;}
.show{opacity:1;transform:translateY(0);}
.contact{background:rgba(0,0,0,0.4);}
.contact h2{color:#00d4ff;}
.contact-form{max-width:600px;margin:40px auto;display:flex;flex-direction:column;gap:20px;}
.input-group{display:flex;gap:20px;}
.contact-form input,.contact-form textarea{width:100%;padding:15px;background:rgba(255,255,255,0.05);border:1px solid rgba(255,255,255,0.2);border-radius:8px;color:white;outline:none;transition:0.3s;}
.contact-form input:focus,.contact-form textarea:focus{border-color:#00d4ff;box-shadow:0 0 10px rgba(0,212,255,0.5);}
.contact-form button{cursor:pointer;border:none;align-self:center;width:200px;}
#status-message{transition:all 0.5s ease;font-weight:bold;margin-bottom:20px;padding:10px;border-radius:5px;}

/* SOCIAL */
.social-icons{display:flex;justify-content:center;gap:15px;flex-wrap:wrap;margin-top:25px;}
.social-icons a{text-decoration:none;font-size:1.5rem;color:#ccc;width:45px;height:45px;display:flex;align-items:center;justify-content:center;border-radius:50%;background:rgba(255,255,255,0.05);border:1px solid rgba(255,255,255,0.1);transition:all 0.4s ease;}
.social-icons a:hover{transform:translateY(-5px);color:#fff;}
.social-icons a[title="WhatsApp"]:hover{color:#25D366;border-color:#25D366;}
.social-icons a[title="Facebook"]:hover{color:#1877F2;border-color:#1877F2;}
.social-icons a[title="Instagram"]:hover{color:#E4405F;border-color:#E4405F;}
.social-icons a[title="YouTube"]:hover{color:#FF0000;border-color:#FF0000;}
.social-icons a[title="X (Twitter)"]:hover{color:#fff;border-color:#fff;}
.social-icons a[title="LinkedIn"]:hover{color:#0077B5;border-color:#0077B5;}
.social-icons a[title="TikTok"]:hover{color:#00f2ea;border-color:#00f2ea;}
.social-icons a[title="Email"]:hover{color:#EA4335;border-color:#EA4335;}

/* CAROUSEL */
.carousel{position:relative;overflow:hidden;width:100%;max-width:900px;margin:auto;border-radius:20px;}
.slides{display:flex;transition:transform 0.6s ease;}
.slide{min-width:100%;position:relative;}
.slide img{width:100%;height:450px;object-fit:cover;border-radius:20px;}
.caption{position:absolute;bottom:20px;left:20px;color:white;background:rgba(0,0,0,0.5);padding:10px 15px;border-radius:10px;}
.prev,.next{position:absolute;top:50%;transform:translateY(-50%);background:rgba(0,0,0,0.5);color:white;border:none;font-size:30px;padding:10px;cursor:pointer;}
.prev{left:10px;} .next{right:10px;}
.dots{text-align:center;margin-top:10px;}
.dot{height:10px;width:10px;margin:5px;display:inline-block;background:#ccc;border-radius:50%;cursor:pointer;}
.dot.active{background:#00d4ff;}

/* PROJECT CARDS */
.project-filters{margin:20px 0;}
.filter{padding:10px 18px;margin:5px;border:none;cursor:pointer;border-radius:20px;background:rgba(255,255,255,0.1);color:white;transition:0.3s;}
.filter.active{background:#00d4ff;color:#000;}
.project-card{background:rgba(255,255,255,0.05);border-radius:15px;overflow:hidden;transition:0.3s;margin-top:15px;}
.project-card:hover{transform:translateY(-8px);}
.project-card img,.project-card video,.project-card iframe{width:100%;height:200px;object-fit:cover;}
.modal{display:none;position:fixed;top:0;left:0;width:100%;height:100%;background:rgba(0,0,0,0.9);justify-content:center;align-items:center;z-index:99999;}
#close{position:absolute;top:20px;right:30px;font-size:40px;color:white;cursor:pointer;}
#modal-content img,#modal-content video{width:80%;max-height:80%;border-radius:10px;}

/* CURSOR */
.cursor-dot,.cursor-outline{position:fixed;top:0;left:0;transform:translate(-50%,-50%);border-radius:50%;z-index:9999;pointer-events:none;}
.cursor-dot{width:8px;height:8px;background:#00d4ff;box-shadow:0 0 10px #00d4ff;}
.cursor-outline{width:30px;height:30px;border:2px solid #00d4ff;}
@media(min-width:768px){body,a,button{cursor:none;}}

/* LANG OVERLAY */
.lang-overlay{position:fixed;top:0;left:0;width:100%;height:100%;background:rgba(0,0,0,0.9);display:flex;justify-content:center;align-items:center;z-index:10000;}
.lang-box{background:#222;padding:30px;border-radius:15px;text-align:center;border:2px solid #00d4ff;color:white;}
.lang-btns button{padding:10px 25px;margin:10px;cursor:pointer;border:none;border-radius:5px;background:#00d4ff;color:#000;font-weight:bold;transition:0.3s;}
.lang-btns button:hover{background:#fff;transform:scale(1.1);}

/* ============================
   FLOAT JOIN BUTTON (NEW)
   ============================ */
#join-float-btn {
    position: fixed;
    bottom: 30px;
    right: 30px;
    background: linear-gradient(135deg, #00d4ff, #0099cc);
    color: #000;
    font-weight: 800;
    font-size: 0.95rem;
    padding: 14px 22px;
    border-radius: 50px;
    cursor: pointer;
    z-index: 5000;
    border: none;
    box-shadow: 0 0 20px rgba(0,212,255,0.7), 0 0 40px rgba(0,212,255,0.4);
    display: flex;
    align-items: center;
    gap: 8px;
    animation: floatBounce 1.5s ease-in-out infinite;
    transition: transform 0.3s, box-shadow 0.3s;
}
#join-float-btn:hover {
    transform: scale(1.1);
    box-shadow: 0 0 30px rgba(0,212,255,1), 0 0 60px rgba(0,212,255,0.6);
}
#join-float-btn i { font-size: 1.1rem; }

/* Pulse ring around float button */
#join-float-btn::before {
    content: '';
    position: absolute;
    width: 100%;
    height: 100%;
    border-radius: 50px;
    border: 2px solid #00d4ff;
    animation: ringPulse 1.5s ease-out infinite;
}
@keyframes floatBounce {
    0%,100%{transform:translateY(0);}
    50%{transform:translateY(-10px);}
}
@keyframes ringPulse {
    0%{transform:scale(1);opacity:1;}
    100%{transform:scale(1.6);opacity:0;}
}

/* ============================
   JOIN MODAL (Login / Register)
   ============================ */
#join-modal {
    display: none;
    position: fixed;
    top:0; left:0; width:100%; height:100%;
    background: rgba(0,0,0,0.85);
    z-index: 9000;
    justify-content: center;
    align-items: center;
    backdrop-filter: blur(5px);
}
#join-modal.active { display: flex; }
.join-box {
    background: #111;
    border: 2px solid #00d4ff;
    border-radius: 20px;
    padding: 35px;
    width: 90%;
    max-width: 480px;
    position: relative;
    animation: slideUp 0.4s ease;
}
@keyframes slideUp{from{transform:translateY(60px);opacity:0;}to{transform:translateY(0);opacity:1;}}
.join-box h2 { color: #00d4ff; margin-bottom: 20px; text-align:center; font-size:1.6rem; }
.join-tabs { display:flex; gap:10px; margin-bottom:25px; }
.join-tab {
    flex:1; padding:10px; border:2px solid #00d4ff; background:transparent;
    color:#00d4ff; border-radius:8px; cursor:pointer; font-weight:600; transition:0.3s;
}
.join-tab.active { background:#00d4ff; color:#000; }
.join-form { display:none; flex-direction:column; gap:14px; }
.join-form.active { display:flex; }
.join-form input, .join-form select, .join-form textarea {
    padding: 12px 15px;
    background: rgba(255,255,255,0.05);
    border: 1px solid rgba(0,212,255,0.4);
    border-radius: 8px;
    color: white;
    outline: none;
    font-size: 0.95rem;
    transition: 0.3s;
    width: 100%;
}
.join-form input:focus, .join-form select:focus {
    border-color: #00d4ff;
    box-shadow: 0 0 10px rgba(0,212,255,0.4);
}
.join-form select option { background:#111; color:white; }
.join-form button[type="submit"] {
    background: linear-gradient(135deg, #00d4ff, #0099cc);
    color: #000; font-weight: 800; padding:13px;
    border:none; border-radius:8px; cursor:pointer; font-size:1rem; transition:0.3s;
}
.join-form button[type="submit"]:hover { transform:scale(1.02); }
.join-close {
    position:absolute; top:12px; right:18px;
    font-size:1.8rem; color:#ccc; cursor:pointer; background:none; border:none;
}
.join-close:hover { color:#00d4ff; }
.join-msg { text-align:center; font-size:0.9rem; margin-top:5px; min-height:20px; }
.join-msg.success { color:#0f0; }
.join-msg.error { color:#f55; }
.role-badges { display:flex; flex-wrap:wrap; gap:8px; margin-bottom:5px; }
.role-badge {
    padding:6px 14px; border-radius:20px;
    border:2px solid rgba(0,212,255,0.4);
    background:transparent; color:#ccc; cursor:pointer; font-size:0.85rem; transition:0.3s;
}
.role-badge.selected { background:#00d4ff; color:#000; border-color:#00d4ff; }
</style>
</head>
<body>

<div class="cursor-dot"></div>
<div class="cursor-outline"></div>

<!-- Language Modal -->
<div id="language-overlay" class="lang-overlay">
    <div class="lang-box">
        <h2>Zabi Yare / Select Language</h2>
        <div class="lang-btns">
            <button onclick="setLanguage('ha')">Hausa</button>
            <button onclick="setLanguage('en')">English</button>
        </div>
    </div>
</div>

<div class="background-overlay"></div>

<!-- NAV -->
<nav>
    <div class="logo">Onetech Dev</div>
    <!-- Hamburger for mobile -->
    <button class="hamburger" id="hamburger" onclick="toggleMenu()" aria-label="Menu">
        <span></span><span></span><span></span>
    </button>
    <ul id="nav-menu">
        <li><a href="#">Gida</a></li>
        <li><a href="#services">Ayyuka</a></li>
        <li><a href="#contact">Tuntuba</a></li>
        <?php if(isLoggedIn()): ?>
        <li><a href="home.php" style="color:#00d4ff;"><i class="fa fa-home"></i> Feed</a></li>
        <li><a href="sakon.php" style="color:#00d4ff;"><i class="fa fa-comment"></i> Saƙo</a></li>
        <li><a href="logout.php" style="color:#f55;">Fita</a></li>
        <?php endif; ?>
    </ul>
</nav>

<!-- HERO -->
<header class="hero">
    <div class="hero-content">
        <div class="profile-container">
            <img src="logo.png" alt="Onetech Dev" class="profile-img">
        </div>
        <h1>Ina Gina <span class="highlight">Manhaja Da Website</span></h1>
        <p id="hero-p"></p>
        <div class="btns">
            <a href="#services" class="btn-primary">Duba Ayyuka Na</a>
            <a href="#contact" class="btn-secondary">Tuntube Ni</a>
        </div>
    </div>
</header>

<!-- SKILLS -->
<section class="skills">
    <div class="skills-container">
        <div class="skill-item"><i class="fa-brands fa-html5"></i><span>HTML5</span></div>
        <div class="skill-item"><i class="fa-brands fa-css3-alt"></i><span>CSS3</span></div>
        <div class="skill-item"><i class="fa-brands fa-js"></i><span>JavaScript</span></div>
        <div class="skill-item"><i class="fa-brands fa-python"></i><span>Python</span></div>
        <div class="skill-item"><i class="fa-brands fa-react"></i><span>React</span></div>
        <div class="skill-item"><i class="fa-solid fa-robot"></i><span>AI & ML</span></div>
        <div class="skill-item"><i class="fa-solid fa-code"></i><span>C++</span></div>
        <div class="skill-item"><i class="fa-solid fa-database"></i><span>SQL</span></div>
        <div class="skill-item"><i class="fa-solid fa-gear"></i><span>CMAKE</span></div>
        <div class="skill-item">
    <i class="fa-solid fa-file-code"></i>
    <span>YAML</span>
</div>
<div class="skill-item">
    <i class="fa-solid fa-terminal"></i>
    <span>Makefile</span>
</div>
    </div>
</section>

<!-- ABOUT -->
<section class="about">
    <h2>About Me</h2><br>
    <p>I am a passionate and results-driven software developer with strong experience in web development, AI systems, and modern business applications.</p><br>
    <p>With a solid foundation in HTML, CSS, JavaScript, Python, and React, I develop high-performance applications that are both visually appealing and technically reliable.</p><br>
    <p>I have worked on projects including business management systems, school and hospital platforms, AI-powered applications, and custom web solutions.</p><br>
    <p>My goal is to create smart digital solutions that not only meet today's needs but are also ready for the future.</p>
</section>

<!-- SERVICES -->
<section id="services" class="services">
    <h2>Abubuwan Da Nake Yi</h2>
    <div class="grid">
        <div class="card"><h3>Business & Data Apps</h3><p>Muna kera apps na kasuwanci da nazarin bayanai.</p></div>
        <div class="card"><h3>School & Hospital Systems</h3><p>Tsarin gudanarwa na zamani don makarantu da asibiti.</p></div>
        <div class="card"><h3>AI & Game Dev</h3><p>Kera manhajoji masu basirar dabdala (AI) da wasanni.</p></div>
    </div>
</section>

<!-- PROJECTS -->
<section class="projects">
    <h2>My Projects</h2>
    <div class="project-filters">
        <button class="filter active" data-filter="all">All</button>
        <button class="filter" data-filter="app">Apps</button>
        <button class="filter" data-filter="ai">AI</button>
        <button class="filter" data-filter="web">Web</button>
    </div>
    <div class="grid">
        <div class="project-card" data-type="app">
            <img src="Screenshot1.jpg" alt="AI App">
            <div style="padding:10px;"><h3>AI Generator App</h3><p>One of our AI generation apps</p></div>
        </div>
        <div class="project-card" data-type="ai">
            <video controls><source src="ai-demo.mp4"></video>
            <div style="padding:10px;"><h3>AI Video Generator</h3><p>Video generated by our AI system</p></div>
        </div>
        <div class="project-card" data-type="web">
            <iframe src="https://www.youtube.com/embed/5svxYq4vtTo" allowfullscreen></iframe>
            <div style="padding:10px;"><h3>YouTube Demo</h3></div>
        </div>
    </div>
</section>

<!-- CAROUSEL -->
<section class="carousel-section">
    <h2>Featured Projects</h2>
    <div class="carousel">
        <div class="slides" id="slides">
            <div class="slide"><img src="business1.jpg"><div class="caption">Business Dashboard App</div></div>
            <div class="slide"><img src="business2.jpg"><div class="caption">Business Dashboard App</div></div>
            <div class="slide"><img src="ai1.jpg"><div class="caption">AI Chatbot</div></div>
            <div class="slide"><img src="ai2.jpg"><div class="caption">AI Chatbot</div></div>
            <div class="slide"><img src="school1.jpg"><div class="caption">School Management System</div></div>
            <div class="slide"><img src="school2.jpg"><div class="caption">School Management System</div></div>
            <div class="slide"><img src="hospital1.jpg"><div class="caption">Hospital System</div></div>
            <div class="slide"><img src="hospital2.jpg"><div class="caption">Hospital System</div></div>
        </div>
        <button class="prev" id="prev">&#10094;</button>
        <button class="next" id="next">&#10095;</button>
        <div class="dots" id="dots"></div>
    </div>
</section>

<!-- WHY ME -->
<section class="why-me">
    <h2>Why Work With Me?</h2>
    <div class="grid">
        <div class="card"><h3>Clean & Maintainable Code</h3><p>Well-structured and scalable code following best practices.</p></div>
        <div class="card"><h3>Performance Optimization</h3><p>Fast, efficient, and responsive applications.</p></div>
        <div class="card"><h3>Modern Technologies</h3><p>Using latest tools like React, AI, and modern frameworks.</p></div>
    </div>
</section>

<!-- CONTACT -->
<section id="contact" class="contact">
    <h2>Tuntube Ni</h2>
    <p id="status-message">Kana da aiki ko tambaya? Rubuto mini sako kai tsaye.</p>
    <form id="my-form" class="contact-form">
        <div class="input-group">
            <input type="text" name="name" placeholder="Sunanka" required>
            <input type="email" name="email" placeholder="Email dinka" required>
        </div>
        <textarea name="message" placeholder="Rubuta sakonka a nan..." rows="5" required></textarea>
        <button type="submit" id="submit-btn" class="btn-primary">Aika Sako</button>
    </form>
    <div class="social-icons">
        <a href="https://wa.me/2348127051112" target="_blank" title="WhatsApp"><i class="fa-brands fa-whatsapp"></i></a>
        <a href="mailto:usmanmannir171@gmail.com" title="Email"><i class="fa-solid fa-envelope"></i></a>
        <a href="tel:+2348127051112" title="Call Me"><i class="fa-solid fa-phone"></i></a>
        <a href="https://www.facebook.com/profile.php?id=61565261292309" target="_blank" title="Facebook"><i class="fa-brands fa-facebook"></i></a>
        <a href="https://www.instagram.com/onetechdev" target="_blank" title="Instagram"><i class="fa-brands fa-instagram"></i></a>
        <a href="https://x.com/usmanmannir137" target="_blank" title="X (Twitter)"><i class="fa-brands fa-x-twitter"></i></a>
        <a href="https://www.youtube.com/@onetechdev" target="_blank" title="YouTube"><i class="fa-brands fa-youtube"></i></a>
        <a href="https://tiktok.com/@onetechdev" target="_blank" title="TikTok"><i class="fa-brands fa-tiktok"></i></a>
        <a href="https://ng.linkedin.com/in/usman-mannir-572975405" target="_blank" title="LinkedIn"><i class="fa-brands fa-linkedin"></i></a>
    </div>
</section>

<!-- ============================
     FLOAT JOIN BUTTON
     ============================ -->
<button id="join-float-btn" onclick="openJoinModal()">
    <i class="fa-solid fa-user-plus"></i>
    <span id="join-btn-text">Join as Developer</span>
</button>

<!-- ============================
     JOIN MODAL
     ============================ -->
<div id="join-modal">
    <div class="join-box">
        <button class="join-close" onclick="closeJoinModal()">&#x2715;</button>
        <h2><i class="fa-solid fa-code"></i> Onetech Community</h2>

        <div class="join-tabs">
            <button class="join-tab active" onclick="switchTab('register')">Register</button>
            <button class="join-tab" onclick="switchTab('login')">Login</button>
        </div>

        <!-- REGISTER FORM -->
        <form id="register-form" class="join-form active" method="POST" action="register.php" enctype="multipart/form-data">
            <input type="hidden" name="action" value="register">
            <input type="text" name="username" placeholder="Username (kamar: onetechdev)" required>
            <input type="email" name="email" placeholder="Email dinka" required>
            <input type="password" name="password" placeholder="Password (min 8 characters)" required>
            <input type="password" name="confirm_pass" placeholder="Tabbatar Password" required>

            <p style="color:#aaa;font-size:0.85rem;margin-bottom:5px;">Zaɓi Nau'inka (Role):</p>
            <div class="role-badges">
                <span class="role-badge" data-role="developer" onclick="selectRole(this)">Developer</span>
                <span class="role-badge" data-role="programmer" onclick="selectRole(this)">Programmer</span>
                <span class="role-badge" data-role="backend_dev" onclick="selectRole(this)">Backend Dev</span>
                <span class="role-badge" data-role="frontend_dev" onclick="selectRole(this)">Frontend Dev</span>
                <span class="role-badge" data-role="server_security" onclick="selectRole(this)">Server Security</span>
            </div>
            <input type="hidden" name="role" id="role-input" required>

            <textarea name="experience" placeholder="Dan gajeren bayani game da ƙwarewarku (experience)..." rows="3"></textarea>
            <button type="submit">Shiga Onetech Community <i class="fa fa-arrow-right"></i></button>
            <div class="join-msg" id="reg-msg"></div>
        </form>

        <!-- LOGIN FORM -->
        <form id="login-form" class="join-form" method="POST" action="login.php">
            <input type="hidden" name="action" value="login">
            <input type="email" name="email" id="login-email" placeholder="Email dinka" required>
            <input type="password" name="password" placeholder="Password" required>
            <button type="submit">Shiga <i class="fa fa-sign-in-alt"></i></button>
            <div style="text-align:center;margin:10px 0;color:#666;font-size:0.85rem;">— ko —</div>
            <button type="button" id="fingerprint-btn" onclick="loginWithFingerprint()" style="background:#1a1a1a;border:2px solid #00d4ff;color:#00d4ff;width:100%;padding:12px;border-radius:8px;cursor:pointer;font-size:1rem;transition:0.3s;">
                <i class="fa fa-fingerprint"></i> Shiga da Yatsa (Fingerprint)
            </button>
            <div class="join-msg" id="login-msg"></div>
        </form>
    </div>
</div>

<!-- PROJECT MODAL -->
<div id="modal" class="modal">
    <span id="close">&times;</span>
    <div id="modal-content"></div>
</div>

<script>
// ================
// TRANSLATIONS
// ================
let currentLang = 'en';
const translations = {
    ha: {
        nav:["Gida","Ayyuka","Tuntuba"],
        heroH1:"Ina Gina <span class='highlight'>Manhaja Da Website</span>",
        heroP:"Ni kwararren Developer ne mai kera Apps (Business, School, Hospital, Games) da AI Solutions.",
        btns:["Duba Ayyuka Na","Tuntube Ni"],
        servicesH2:"Abubuwan Da Nake Yi",
        cards:[
            {h3:"Business & Data Apps",p:"Muna kera apps na kasuwanci da nazarin bayanai."},
            {h3:"School & Hospital Systems",p:"Tsarin gudanarwa na zamani don makarantu da asibiti."},
            {h3:"AI & Game Dev",p:"Kera AI systems da wasanni masu smart logic."}
        ],
        contactH2:"Tuntube Ni",
        status:"Kana da aiki ko tambaya? Rubuto mini sako kai tsaye.",
        form:["Sunanka","Email dinka","Rubuta sakonka a nan...","Aika Sako"],
        success:"✅ An gode! Na karbi sakonka.",
        error:"❌ Akwai matsala, sake gwadawa.",
        joinBtn:"Shiga Onetech"
    },
    en: {
        nav:["Home","Services","Contact"],
        heroH1:"I Build <span class='highlight'>Apps & Websites</span>",
        heroP:"I am a professional Developer building scalable Apps, AI systems, and modern business solutions.",
        btns:["View My Work","Contact Me"],
        servicesH2:"What I Do",
        cards:[
            {h3:"Business & Data Apps",p:"We build business systems and data tools."},
            {h3:"School & Hospital Systems",p:"Modern management systems for institutions."},
            {h3:"AI & Game Dev",p:"Developing AI-powered apps and games."}
        ],
        contactH2:"Contact Me",
        status:"Have a project or question? Send me a message.",
        form:["Your Name","Your Email","Write your message...","Send Message"],
        success:"✅ Message sent successfully!",
        error:"❌ Something went wrong!",
        joinBtn:"Join as Developer"
    }
};

// ================
// INIT
// ================
document.addEventListener("DOMContentLoaded",()=>{
    const saved = localStorage.getItem("userLanguage");
    if(saved) setLanguage(saved); else document.getElementById("language-overlay").style.display="flex";
    initCursor();
    initScroll();
    initForm();
    initFilters();
    initModal();
    initSlider();
    startJoinBtnRotation();
});

// ================
// LANGUAGE
// ================
function setLanguage(lang){
    currentLang=lang;
    localStorage.setItem("userLanguage",lang);
    const t=translations[lang]||translations.en;
    document.querySelectorAll("nav ul li a").forEach((el,i)=>{ if(t.nav[i]) el.innerText=t.nav[i]; });
    const h1=document.querySelector(".hero h1");
    const p=document.getElementById("hero-p");
    if(h1) h1.innerHTML=t.heroH1;
    if(p) startTyping(t.heroP);
    document.querySelector(".services h2").innerText=t.servicesH2;
    document.querySelectorAll(".card").forEach((c,i)=>{
        if(t.cards[i]){
            const h=c.querySelector("h3"); const pp=c.querySelector("p");
            if(h) h.innerText=t.cards[i].h3;
            if(pp) pp.innerText=t.cards[i].p;
        }
    });
    document.querySelector(".btn-primary").innerText=t.btns[0];
    document.querySelector(".btn-secondary").innerText=t.btns[1];
    document.querySelector(".contact h2").innerText=t.contactH2;
    document.getElementById("status-message").innerText=t.status;
    document.getElementsByName("name")[0].placeholder=t.form[0];
    document.getElementsByName("email")[0].placeholder=t.form[1];
    document.getElementsByName("message")[0].placeholder=t.form[2];
    document.getElementById("submit-btn").innerText=t.form[3];
    const ov=document.getElementById("language-overlay");
    if(ov) ov.style.display="none";
}

// ================
// TYPING EFFECT
// ================
function startTyping(text){
    const el=document.getElementById("hero-p");
    if(!el) return;
    el.innerHTML=""; let i=0;
    function type(){ if(i<text.length){ el.innerHTML+=text.charAt(i); i++; setTimeout(type,25); } }
    type();
}

// ================
// JOIN FLOAT BTN ROTATION
// Shows different roles every 5sec
// ================
const joinRoles=["Join as Developer","Join as Programmer","Join as Backend Dev","Join as Frontend Dev","Join as Server Security"];
let roleIdx=0;
function startJoinBtnRotation(){
    setInterval(()=>{
        roleIdx=(roleIdx+1)%joinRoles.length;
        const el=document.getElementById("join-btn-text");
        if(el){
            el.style.opacity="0";
            setTimeout(()=>{ el.textContent=joinRoles[roleIdx]; el.style.opacity="1"; },300);
        }
    },5000);
}

// ================
// JOIN MODAL
// ================
function openJoinModal(){
    document.getElementById("join-modal").classList.add("active");
    document.body.style.overflow="hidden";
}
function closeJoinModal(){
    document.getElementById("join-modal").classList.remove("active");
    document.body.style.overflow="";
}
document.getElementById("join-modal").addEventListener("click",function(e){
    if(e.target===this) closeJoinModal();
});

function switchTab(tab){
    document.querySelectorAll(".join-tab").forEach(t=>t.classList.remove("active"));
    document.querySelectorAll(".join-form").forEach(f=>f.classList.remove("active"));
    if(tab==="register"){
        document.querySelectorAll(".join-tab")[0].classList.add("active");
        document.getElementById("register-form").classList.add("active");
    } else {
        document.querySelectorAll(".join-tab")[1].classList.add("active");
        document.getElementById("login-form").classList.add("active");
    }
}

function selectRole(el){
    document.querySelectorAll(".role-badge").forEach(b=>b.classList.remove("selected"));
    el.classList.add("selected");
    document.getElementById("role-input").value=el.dataset.role;
}

// ================
// CURSOR
// ================
function initCursor(){
    const dot=document.querySelector(".cursor-dot");
    const outline=document.querySelector(".cursor-outline");
    if(!dot||!outline) return;
    window.addEventListener("mousemove",e=>{
        dot.style.left=e.clientX+"px"; dot.style.top=e.clientY+"px";
        outline.animate({left:e.clientX+"px",top:e.clientY+"px"},{duration:200,fill:"forwards"});
    });
}

// ================
// SCROLL ANIMATION
// ================
function initScroll(){
    const obs=new IntersectionObserver(entries=>{
        entries.forEach(e=>{ if(e.isIntersecting) e.target.classList.add("show"); });
    },{threshold:0.2});
    document.querySelectorAll(".card,.project-card").forEach(el=>{
        el.classList.add("hidden"); obs.observe(el);
    });
}

// ================
// CONTACT FORM
// ================
function initForm(){
    const form=document.getElementById("my-form");
    if(!form) return;
    form.addEventListener("submit",async e=>{
        e.preventDefault();
        const btn=document.getElementById("submit-btn");
        const msg=document.getElementById("status-message");
        const t=translations[currentLang];
        btn.disabled=true; btn.innerText="Sending...";
        try{
            const res=await fetch("https://formspree.io/f/mnjovylw",{
                method:"POST", body:new FormData(form), headers:{Accept:"application/json"}
            });
            msg.innerText=res.ok?t.success:t.error;
            if(res.ok) form.reset();
        }catch{ msg.innerText="Network Error!"; }
        btn.disabled=false; btn.innerText=t.form[3];
    });
}

// ================
// FILTERS
// ================
function initFilters(){
    document.querySelectorAll(".filter").forEach(btn=>{
        btn.addEventListener("click",()=>{
            document.querySelectorAll(".filter").forEach(b=>b.classList.remove("active"));
            btn.classList.add("active");
            const type=btn.dataset.filter;
            document.querySelectorAll(".project-card").forEach(c=>{
                c.style.display=(type==="all"||c.dataset.type===type)?"block":"none";
            });
        });
    });
}

// ================
// MODAL
// ================
function initModal(){
    const modal=document.getElementById("modal");
    const content=document.getElementById("modal-content");
    const close=document.getElementById("close");
    if(!modal||!content||!close) return;
    document.querySelectorAll(".project-card img,.project-card video,.project-card iframe").forEach(el=>{
        el.addEventListener("click",()=>{ modal.style.display="flex"; content.innerHTML=el.outerHTML; });
    });
    close.onclick=()=>{ modal.style.display="none"; content.innerHTML=""; };
}

// ================
// SLIDER
// ================
function initSlider(){
    const slides=document.getElementById("slides");
    const items=document.querySelectorAll(".slide");
    const dotsBox=document.getElementById("dots");
    if(!slides||items.length===0||!dotsBox) return;
    let idx=0;
    items.forEach((_,i)=>{
        const dot=document.createElement("span");
        dot.classList.add("dot");
        if(i===0) dot.classList.add("active");
        dot.onclick=()=>go(i);
        dotsBox.appendChild(dot);
    });
    const dots=document.querySelectorAll(".dot");
    function update(){ slides.style.transform=`translateX(-${idx*100}%)`; dots.forEach(d=>d.classList.remove("active")); dots[idx].classList.add("active"); }
    function go(i){ idx=i; update(); }
    function next(){ idx=(idx+1)%items.length; update(); }
    let auto=setInterval(next,4000);
    document.querySelector(".carousel")?.addEventListener("mouseenter",()=>clearInterval(auto));
    document.querySelector(".carousel")?.addEventListener("mouseleave",()=>auto=setInterval(next,4000));
    document.getElementById("next")?.addEventListener("click",next);
    document.getElementById("prev")?.addEventListener("click",()=>{ idx=(idx-1+items.length)%items.length; update(); });
}

// Hamburger menu toggle
function toggleMenu() {
    const menu = document.getElementById('nav-menu');
    const btn  = document.getElementById('hamburger');
    menu.classList.toggle('open');
    btn.classList.toggle('open');
}
// Close menu when a link is clicked
document.querySelectorAll('#nav-menu a').forEach(a=>{
    a.addEventListener('click', ()=>{
        document.getElementById('nav-menu').classList.remove('open');
        document.getElementById('hamburger').classList.remove('open');
    });
});

// ── FINGERPRINT LOGIN ──────────────────────────────────────────────────
async function loginWithFingerprint() {
    const emailEl = document.getElementById('login-email');
    const msgEl   = document.getElementById('login-msg');
    const email   = emailEl ? emailEl.value.trim() : '';
    if (!email) {
        msgEl.style.color='#ff4444';
        msgEl.textContent = '⚠️ Da farko ka rubuta email dinka';
        return;
    }
    if (!window.PublicKeyCredential) {
        msgEl.style.color='#ff4444';
        msgEl.textContent = '❌ Wannan na'am baya goyon bayan fingerprint';
        return;
    }
    msgEl.style.color='#00d4ff';
    msgEl.textContent = '🔍 Ana duba yatsanka...';
    try {
        // Step 1: Get challenge from server
        const res = await fetch('webauthn-login.php', {
            method:'POST',
            headers:{'Content-Type':'application/json'},
            body: JSON.stringify({action:'get', email})
        });
        const data = await res.json();
        if (!data.success) {
            msgEl.style.color='#ff4444';
            msgEl.textContent = '❌ ' + data.message;
            return;
        }
        // Step 2: Request fingerprint via browser
        const credId = Uint8Array.from(atob(data.credentialId.replace(/-/g,'+').replace(/_/g,'/')), c=>c.charCodeAt(0));
        const challenge = Uint8Array.from(atob(data.challenge.replace(/-/g,'+').replace(/_/g,'/')), c=>c.charCodeAt(0));
        const assertion = await navigator.credentials.get({
            publicKey: {
                challenge,
                allowCredentials: [{type:'public-key', id: credId}],
                userVerification: 'required',
                timeout: 60000
            }
        });
        // Step 3: Verify with server
        const verifyRes = await fetch('webauthn-login.php', {
            method:'POST',
            headers:{'Content-Type':'application/json'},
            body: JSON.stringify({action:'verify', id: data.credentialId, email})
        });
        const verifyData = await verifyRes.json();
        if (verifyData.success) {
            msgEl.style.color='#00ff88';
            msgEl.textContent = '✅ An shiga! Ana canja...';
            setTimeout(()=>location.href='home.php', 1000);
        } else {
            msgEl.style.color='#ff4444';
            msgEl.textContent = '❌ ' + verifyData.message;
        }
    } catch(err) {
        msgEl.style.color='#ff4444';
        msgEl.textContent = '❌ An soke ko akwai matsala: ' + err.message;
    }
}
</script>
</body>
</html>