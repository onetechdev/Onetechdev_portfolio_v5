<?php
/**
 * ONETECH DEV — Facebook Algorithm Feed v2
 * =========================================
 * Layer A (50%) — Mutanen da ka bi
 * Layer B (25%) — Trending / Popular
 * Layer C (25%) — Discovery / Gano
 *
 * Scoring:
 *  Mutual follow   → ×120
 *  Following       → ×75
 *  Follows me only → ×30
 *  Interest graph  → ×60
 *  Comment         → ×5 each
 *  Like            → ×3 each
 *  Share           → ×4 each
 *  Video           → +30
 *  Image           → +15
 *  50+ engage      → +40
 *  100+ engage     → +80
 *  Recency decay applied last
 */

require_once 'inc/config.php';
if (!isLoggedIn()) exit;

$viewer_id = $_SESSION['user_id'];
$page      = max(1, (int)($_GET['page'] ?? 1));
$limit     = 15;

// ── 1. Who I follow / who follows me ─────────────────────
$following_ids = [];
$r1 = $conn->query("SELECT following_id FROM follows WHERE follower_id=$viewer_id");
while ($row = $r1->fetch_assoc()) $following_ids[] = (int)$row['following_id'];

$follower_ids = [];
$r2 = $conn->query("SELECT follower_id FROM follows WHERE following_id=$viewer_id");
while ($row = $r2->fetch_assoc()) $follower_ids[] = (int)$row['follower_id'];

$mutual_ids = array_intersect($following_ids, $follower_ids);

// Interest graph (last 30 days)
$interest_ids = [];
$r3 = $conn->query("SELECT DISTINCT post_owner_id FROM post_interactions
    WHERE user_id=$viewer_id AND action IN('like','comment','save')
    AND created_at >= DATE_SUB(NOW(), INTERVAL 30 DAY)");
if ($r3) while ($row = $r3->fetch_assoc()) $interest_ids[] = (int)$row['post_owner_id'];

// Session-based seen filter
if (!isset($_SESSION['seen_posts'])) $_SESSION['seen_posts'] = [];
$seen_str = implode(',', array_map('intval', $_SESSION['seen_posts'])) ?: '0';

// ── 2. Candidate posts (up to 300 recent) ────────────────
$follow_in = implode(',', $following_ids) ?: '0';

$sql = "
    SELECT
        p.id, p.user_id, p.content, p.media_url, p.media_type,
        p.likes_count, p.comments_count,
        COALESCE(p.view_count,0) AS view_count,
        COALESCE(p.share_count,0) AS share_count,
        p.created_at,
        u.username, u.profile_pic, u.role,
        (SELECT COUNT(*) FROM post_likes WHERE post_id=p.id AND user_id=$viewer_id) AS i_liked,
        (SELECT id       FROM post_saves  WHERE post_id=p.id AND user_id=$viewer_id) AS i_saved
    FROM posts p
    JOIN users u ON p.user_id = u.id
    WHERE p.post_type = 'post'
      AND p.user_id != $viewer_id
      AND p.id NOT IN ($seen_str)
    ORDER BY p.created_at DESC
    LIMIT 300
";

$q = $conn->query($sql);
if (!$q || $q->num_rows === 0) {
    // Clear seen list and retry
    $_SESSION['seen_posts'] = [];
    $q = $conn->query(str_replace("AND p.id NOT IN ($seen_str)", "", $sql));
}

// ── 3. Score each post ───────────────────────────────────
$scored = [];
$per_user = [];

while ($p = $q->fetch_assoc()) {
    $uid  = (int)$p['user_id'];
    $score = 0;

    // Relationship
    if (in_array($uid, array_values($mutual_ids)))   $score += 120;
    elseif (in_array($uid, $following_ids))           $score += 75;
    elseif (in_array($uid, $follower_ids))            $score += 30;

    // Interest graph
    if (in_array($uid, $interest_ids)) $score += 60;

    // Engagement
    $score += (int)$p['likes_count']    * 3;
    $score += (int)$p['comments_count'] * 5;
    $score += (int)$p['share_count']    * 4;

    // Recency decay
    $hrs = max(0.1, (time() - strtotime($p['created_at'])) / 3600);
    $decay = match(true) {
        $hrs <=  1 => 1.00,
        $hrs <=  6 => 0.85,
        $hrs <= 12 => 0.70,
        $hrs <= 24 => 0.55,
        $hrs <= 48 => 0.35,
        $hrs <= 72 => 0.20,
        default    => 0.08,
    };
    $score = (int)($score * $decay);

    // Media boost
    if ($p['media_type'] === 'video')       $score += 30;
    elseif ($p['media_type'] === 'image')   $score += 15;

    // Viral bonus
    $engage = (int)$p['likes_count'] + (int)$p['comments_count'];
    if ($engage >  50) $score += 40;
    if ($engage > 100) $score += 80;

    // Diversity cap: max 3 posts per user per load
    if (!isset($per_user[$uid])) $per_user[$uid] = 0;
    if ($per_user[$uid] >= 3) continue;
    $per_user[$uid]++;

    $p['_score'] = $score;
    $scored[] = $p;
}

// ── 4. Sort by score ────────────────────────────────────
usort($scored, fn($a,$b) => $b['_score'] <=> $a['_score']);

// ── 5. Layer mixing A-A-B-A-A-C ─────────────────────────
$layer_a = array_values(array_filter($scored,
    fn($p) => in_array($p['user_id'], $following_ids) || in_array($p['user_id'], array_values($mutual_ids))));
$layer_b = array_values(array_filter($scored,
    fn($p) => !in_array($p['user_id'], $following_ids) &&
              ((int)$p['likes_count'] + (int)$p['comments_count']) > 5));
$layer_c = array_values(array_filter($scored,
    fn($p) => !in_array($p['user_id'], $following_ids) &&
              ((int)$p['likes_count'] + (int)$p['comments_count']) <= 5));

$feed = []; $ai = $bi = $ci = 0;
while (count($feed) < $limit) {
    // A A B A A C
    for ($i=0;$i<2&&count($feed)<$limit;$i++) {
        if (isset($layer_a[$ai]))       $feed[] = $layer_a[$ai++];
        elseif (isset($layer_b[$bi]))   $feed[] = $layer_b[$bi++];
        elseif (isset($layer_c[$ci]))   $feed[] = $layer_c[$ci++];
        else break 2;
    }
    if (count($feed)<$limit) {
        if (isset($layer_b[$bi]))       $feed[] = $layer_b[$bi++];
        elseif (isset($layer_a[$ai]))   $feed[] = $layer_a[$ai++];
        elseif (isset($layer_c[$ci]))   $feed[] = $layer_c[$ci++];
    }
    for ($i=0;$i<2&&count($feed)<$limit;$i++) {
        if (isset($layer_a[$ai]))       $feed[] = $layer_a[$ai++];
        elseif (isset($layer_b[$bi]))   $feed[] = $layer_b[$bi++];
        elseif (isset($layer_c[$ci]))   $feed[] = $layer_c[$ci++];
        else break 2;
    }
    if (count($feed)<$limit) {
        if (isset($layer_c[$ci]))       $feed[] = $layer_c[$ci++];
        elseif (isset($layer_b[$bi]))   $feed[] = $layer_b[$bi++];
        elseif (isset($layer_a[$ai]))   $feed[] = $layer_a[$ai++];
    }
    if ($ai>=count($layer_a) && $bi>=count($layer_b) && $ci>=count($layer_c)) break;
}

// ── 6. Empty state ───────────────────────────────────────
if (empty($feed)) {
    echo '<div class="feed-empty" style="text-align:center;padding:50px 20px;color:#555;">
            <i class="fa fa-newspaper" style="font-size:2.5rem;display:block;margin-bottom:12px;"></i>
            <div style="font-size:.9rem;">Feed ɗinka ya ƙare — bi ƙarin mutane!</div>
          </div>';
    exit;
}

// ── 7. Render ────────────────────────────────────────────
function time_ago($dt) {
    $s = time() - strtotime($dt);
    if ($s < 60)     return $s.'s';
    if ($s < 3600)   return floor($s/60).'m';
    if ($s < 86400)  return floor($s/3600).'h';
    if ($s < 604800) return floor($s/86400).'d';
    return date('d M', strtotime($dt));
}

$insert_suggest_every = 5; // show "People you may know" every 5 posts
$post_idx = 0;

foreach ($feed as $p):
    $pid     = (int)$p['id'];
    $uid     = (int)$p['user_id'];
    $pic     = $p['profile_pic'] ? 'uploads/'.htmlspecialchars($p['profile_pic']) : 'assets/default.png';
    $uname   = htmlspecialchars($p['username']);
    $content = htmlspecialchars($p['content'] ?? '');
    $ago     = time_ago($p['created_at']);
    $liked   = $p['i_liked'] ? 'liked' : '';
    $saved   = $p['i_saved'] ? 'saved' : '';

    $is_following = in_array($uid, $following_ids);
    $is_mutual    = in_array($uid, array_values($mutual_ids));
    $engage       = (int)$p['likes_count'] + (int)$p['comments_count'];
    $is_trending  = $engage > 20;

    $ctx = '';
    if ($is_mutual)        $ctx = '<span style="font-size:.65rem;color:#2ecc71;"><i class="fa fa-user-friends"></i> Aboki</span>';
    elseif ($is_trending)  $ctx = '<span style="font-size:.65rem;color:#e67e22;"><i class="fa fa-fire"></i> Trending</span>';
    elseif (!$is_following) $ctx = '<span style="font-size:.65rem;color:#888;"><i class="fa fa-compass"></i> Gano</span>';

    // Track view + add to seen
    $conn->query("UPDATE posts SET view_count=COALESCE(view_count,0)+1 WHERE id=$pid");
    $conn->query("INSERT INTO post_interactions (user_id,post_id,post_owner_id,action)
        VALUES($viewer_id,$pid,$uid,'view') ON DUPLICATE KEY UPDATE created_at=NOW()");
    $_SESSION['seen_posts'][] = $pid;
    if (count($_SESSION['seen_posts']) > 300) $_SESSION['seen_posts'] = array_slice($_SESSION['seen_posts'],-200);

    echo <<<HTML
<div class="post-card" id="post-{$pid}">
    <div class="post-header">
        <img src="{$pic}" onerror="this.src='assets/default.png'" onclick="showProfilePopup({$uid})">
        <div style="flex:1;min-width:0;">
            <div class="post-name" onclick="showProfilePopup({$uid})">{$uname}
                <span class="post-role">{$p['role']}</span>
            </div>
            <div class="post-time"><i class="fa fa-clock"></i> {$ago}
                {$ctx}
            </div>
        </div>
        <button class="post-options" onclick="togglePostMenu({$pid})"><i class="fa fa-ellipsis-h"></i></button>
    </div>

    <div class="post-menu" id="pmenu-{$pid}">
HTML;
    if (!$is_following && !$is_mutual) echo "
        <div class='pmenu-item' onclick=\"followUser($uid,this);togglePostMenu($pid)\">
            <i class='fa fa-user-plus' style='color:#2ecc71;'></i> Bi $uname</div>";
    echo "
        <div class='pmenu-item' onclick=\"savePost($pid,document.getElementById('save-btn-$pid'));togglePostMenu($pid)\">
            <i class='fa fa-bookmark' style='color:var(--accent);'></i> " . ($p['i_saved']?'Cire daga Saved':'Save Post') . "</div>
        <div class='pmenu-item' onclick=\"sharePost($pid);togglePostMenu($pid)\">
            <i class='fa fa-share' style='color:#3498db;'></i> Share</div>
    </div>";

    if ($content) echo "<div class='post-text'>".nl2br($content)."</div>";

    if ($p['media_type'] === 'image' && $p['media_url']) {
        $src = htmlspecialchars($p['media_url']);
        echo "<img class='post-media' src='{$src}' loading='lazy' onerror=\"this.style.display='none'\"
              onclick=\"openMedia('image','{$src}')\">";
    }
    if ($p['media_type'] === 'video' && $p['media_url']) {
        $src = htmlspecialchars($p['media_url']);
        echo "<div class='post-video-wrap'>
            <video src='{$src}' preload='metadata' playsinline loop muted data-pid='{$pid}'
                   onclick='togglePlay(this)'></video>
            <div class='vid-play-overlay'><i class='fa fa-play-circle'></i></div>
            <div style='padding:4px 12px;font-size:.72rem;color:#888;'>
                <i class='fa fa-eye'></i> ".number_format((int)$p['view_count'])." views</div>
        </div>";
    }

    $lcount = $p['likes_count'] > 0 ? '❤️ '.$p['likes_count'] : '';
    $ccount = $p['comments_count'] > 0 ? $p['comments_count'].' comments' : '';
    echo "
    <div class='post-stats'>
        <span id='like-count-{$pid}'>{$lcount}</span>
        <span id='comment-count-{$pid}'>{$ccount}</span>
    </div>
    <div class='post-actions'>
        <button class='post-action-btn {$liked}' id='like-btn-{$pid}' onclick='likePost({$pid})'>
            <i class='".($p['i_liked']?'fa':'far')." fa-heart'></i> Like</button>
        <button class='post-action-btn' onclick='toggleComments({$pid})'>
            <i class='fa fa-comment'></i> Comment</button>
        <button class='post-action-btn' onclick='sharePost({$pid})'>
            <i class='fa fa-share'></i> Share</button>
        <button class='post-action-btn {$saved}' id='save-btn-{$pid}' onclick='savePost({$pid},this)'>
            <i class='fa fa-bookmark'></i></button>
    </div>

    <div class='comments-box' id='cbox-{$pid}'>
        <div class='comment-input-row'>
            <img src='uploads/".($GLOBALS['_me_pic']??'')."' onerror=\"this.src='assets/default.png'\">
            <input type='text' id='cinput-{$pid}' placeholder='Rubuta comment...'
                   onkeydown=\"if(event.key==='Enter')sendComment({$pid})\">
            <button onclick='sendComment({$pid})'><i class='fa fa-paper-plane'></i></button>
        </div>
        <div id='clist-{$pid}'></div>
    </div>
</div>
";

    // "People you may know" card every 5 posts
    $post_idx++;
    if ($post_idx % $insert_suggest_every === 0) {
        $rnd = $conn->query("SELECT u.id,u.username,u.profile_pic,u.role FROM users u
            WHERE u.id != $viewer_id AND u.id != $uid
            AND u.id NOT IN (SELECT following_id FROM follows WHERE follower_id=$viewer_id)
            ORDER BY RAND() LIMIT 3");
        if ($rnd && $rnd->num_rows > 0) {
            echo "<div class='suggest-card' style='margin-bottom:12px;'>
                <h4><i class='fa fa-users'></i> Mutane Za Ka Iya Bi</h4>";
            while ($su = $rnd->fetch_assoc()) {
                $sp = $su['profile_pic'] ? 'uploads/'.htmlspecialchars($su['profile_pic']) : 'assets/default.png';
                $sn = htmlspecialchars($su['username']);
                echo "<div class='suggest-item'>
                    <img src='{$sp}' onerror=\"this.src='assets/default.png'\" onclick='showProfilePopup({$su['id']})'>
                    <div>
                        <div class='si-name' onclick='showProfilePopup({$su['id']})'>{$sn}</div>
                        <div class='si-role'>{$su['role']}</div>
                    </div>
                    <button class='follow-btn' onclick='followUser({$su['id']},this)'><i class='fa fa-user-plus'></i> Bi</button>
                </div>";
            }
            echo "</div>";
        }
    }

endforeach;
