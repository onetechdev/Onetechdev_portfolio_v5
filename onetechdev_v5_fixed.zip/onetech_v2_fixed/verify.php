<?php
require_once 'inc/config.php';

$token = clean($conn, $_GET['token'] ?? '');

if (!empty($token)) {
    $res = $conn->query("SELECT id FROM users WHERE verify_token='$token' AND is_verified=0");
    if ($res->num_rows === 1) {
        $user = $res->fetch_assoc();
        $conn->query("UPDATE users SET is_verified=1, verify_token='' WHERE id={$user['id']}");
        $msg = "✅ Email an tabbatar! Yanzu kana iya shiga.";
    } else {
        $msg = "❌ Token ba daidai ba ne ko an riga an tabbatar.";
    }
} else {
    $msg = "❌ Token ba ya nan.";
}
?>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Verify - Onetech Dev</title>
<style>
body{background:#111;color:white;display:flex;align-items:center;justify-content:center;height:100vh;font-family:Poppins,sans-serif;}
.box{text-align:center;background:#222;padding:40px;border-radius:15px;border:2px solid #00d4ff;}
h2{color:#00d4ff;}
a{color:#00d4ff;display:inline-block;margin-top:20px;}
</style>
</head>
<body>
<div class="box">
    <h2><?= $msg ?></h2>
    <a href="index.php">← Koma Gida</a>
</div>
</body>
</html>